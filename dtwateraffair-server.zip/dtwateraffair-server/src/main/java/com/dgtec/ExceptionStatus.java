package com.dgtec;

import lombok.Getter;

@Getter
public enum ExceptionStatus {

    CONNECT_SUCCESS(1, "connentSuccess"),
    CONNECT_FAILURE(2, "connentFailure");



     private Integer code;
     private String message;

    ExceptionStatus(Integer code, String message) {
         this.code = code;
         this.message = message;
     }

}
