package com.dgtec;

public class PageException extends Exception {
    public PageException(String message) {
        super(message);
    }
}
