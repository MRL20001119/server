package com.dgtec;

public class JsonException extends Exception {

    Object data;

    public JsonException(String message) {
        super(message);
    }

    public JsonException(String message, Object t) {
        super(message);

        this.data = t;
    }

    public Object getData() {
        return this.data;
    }

}
