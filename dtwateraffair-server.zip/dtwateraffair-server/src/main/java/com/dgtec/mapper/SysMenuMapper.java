package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysUser;
import com.dgtec.system.model.Menu;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SysMenuMapper extends BaseMapper<Menu> {

    public List<Menu> findAll2Tenant(@Param("tenantId") Integer tenantId);

    /**
     * 查询用户菜单权限
     * @param user
     * @return
     */
    public List<Menu> findAll2User(@Param("user") SysUser user, @Param("nodeProps") Integer[] nodeProps);

    /**
     * 查询用户按钮权限
     * @param user
     * @return
     */
    public List<String> findIntfPermissions2User(@Param("user") SysUser user);

    public Integer getMaxId();

    //public Integer insert(Menu menu);

    public void deleteAll(@Param("tenantId") Integer tenantId);

}