package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysUser;
import com.dgtec.entity.SysUserRole;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

    //public List<Integer> findMenuIdListGrantRoleId(@Param("roleId") Integer roleId,
    //                                               @Param("triState") String triState);

    /**
     * 保存角色的菜单关系
     */
    //void saveAll(SysRoleEntity role);

    /**
     * 删除角色的菜单关系
     */
    //void deleteByRole(@Param("role") SysRole role);

    /**
     * 删除用户的角色关系
     */
    void deleteByUser(@Param("user") SysUser user);

}