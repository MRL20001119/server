package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysLog;
import org.springframework.stereotype.Repository;

@Repository
public interface SysLogMapper extends BaseMapper<SysLog> {

}