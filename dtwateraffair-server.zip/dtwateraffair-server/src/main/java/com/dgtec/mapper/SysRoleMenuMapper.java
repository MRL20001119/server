package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysRole;
import com.dgtec.entity.SysRoleMenu;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {

    public List<Integer> findMenuIdListGrantRoleId(@Param("roleId") Integer roleId,
                                                   @Param("triState") String triState);

    /**
     * 删除角色的菜单关系
     */
    void deleteByRole(@Param("role") SysRole role);

}