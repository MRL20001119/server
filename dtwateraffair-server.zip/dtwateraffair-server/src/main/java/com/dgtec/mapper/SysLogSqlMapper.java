package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysLogSql;
import org.springframework.stereotype.Repository;

@Repository
public interface SysLogSqlMapper extends BaseMapper<SysLogSql> {

}