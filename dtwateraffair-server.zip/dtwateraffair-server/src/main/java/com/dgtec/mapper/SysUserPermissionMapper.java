package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysUser;
import com.dgtec.entity.SysUserPermission;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SysUserPermissionMapper extends BaseMapper<SysUserPermission> {

    public List<Integer> findAreaIdListGrantUser(@Param("user") SysUser user);

    /**
     * 保存角色的菜单关系
     */
    //public List<String> getPermissions(@Param("user") SysUser user);

    /**
     * 解除用户的数据授权
     */
    void deleteByUser(@Param("user") SysUser user);

}