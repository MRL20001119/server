package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysRole;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Repository
public interface SysRoleMapper extends BaseMapper<SysRole> {


    /**
     * 查询用户，并同时返回每个用户拥有的权限
     * @param role
     */
    List<SysRole> findList(@Param("role") SysRole role,
                    @Param("start") Long start, @Param("limit") Long limit);

    //    User getUserByUsername0(String username);
//
//    User getUserById(Integer id);
//
//    List<User> getAllUser();
//
//    Integer addUser(User user);
//
//    Integer updateUserById(User user);
//
//    Integer deleteUserById(Integer id);

    @MapKey("name")
    public Map<String, SysRole> findMap(@Param("roleNames") Set<String> roleNames, @Param("tenantId") Integer tenantId);
}