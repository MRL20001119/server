package com.dgtec.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dgtec.entity.SysUser;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 系统用户
 *
 */
@Repository
public interface SysUserMapper extends BaseMapper<SysUser> {

	/**
	 * 根据用户名，查询系统用户
	 */
	SysUser getUserByUsername(String username);

	/**
	 * 查询用户，并同时返回每个用户拥有的权限
	 * @param user
	 */
	List<SysUser> findList(@Param("user") SysUser user,
					@Param("start") Long start, @Param("limit") Long limit);

	/**
	 * 分角色查询用户，并同时返回每个用户拥有的权限
	 * @param roleId
	 */
	List<SysUser> findListGrantRole(@Param("roleId") Integer roleId, @Param("tenantId") Integer tenantId);

//	/**
//	 * 查询用户的所有权限
//	 * @param userId  用户ID
//	 */
//	List<String> findAllAuth(Long userId);
	
//	SysUser getUserById(Integer id);

//	List<User> findAll();

//	Integer addUser(SysUser user);

//	Integer updateUserById(SysUser user);

	//Integer deleteUserById(Integer id);

}
