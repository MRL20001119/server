package com.dgtec.modulars.base.service.impl;

import com.dgtec.modulars.base.service.BaseService;

/**
 * 基础Service实现
 * 本类中方法为公共方法
 */
public abstract class BaseServiceImpl implements BaseService {

}
