package com.dgtec.modulars.test.vo;

import lombok.Data;

/**
 *  前端展示用实体类
 */
@Data
public class TestVO {
    /**
     *  主键
     */
    private Integer id;

    /**
     *  用户名
     */
    private String username;
}
