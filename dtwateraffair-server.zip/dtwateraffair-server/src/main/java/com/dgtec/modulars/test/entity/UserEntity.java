package com.dgtec.modulars.test.entity;

import lombok.Data;

/**
 *  用户
 */
@Data
public class UserEntity {

    /**
     *  主键
     */
    private Integer id;

    /**
     *  用户名
     */
    private String username;

}
