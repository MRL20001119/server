package com.dgtec.modulars.test.service.impl;

import com.dgtec.modulars.base.service.impl.BaseServiceImpl;
import com.dgtec.modulars.test.entity.UserEntity;
import com.dgtec.modulars.test.mapper.TestMapper;
import com.dgtec.modulars.test.service.TestService;
import com.dgtec.modulars.test.vo.TestVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 *  测试Service实现
 */
@Service("testService")
public class TestServiceImpl extends BaseServiceImpl implements TestService {

    @Autowired
    private TestMapper testMapper;

    /**
     *  查询用户列表
     * @return 用户列表
     */
    @Override
    public List<TestVO> getUserList() {
        List<UserEntity> entityList = testMapper.getUser();
        List<TestVO> voList = new ArrayList<>();
        for(UserEntity entity : entityList) {
            TestVO vo = new TestVO();
            BeanUtils.copyProperties(entity, vo);
            voList.add(vo);
        }
        return voList;
    }

}
