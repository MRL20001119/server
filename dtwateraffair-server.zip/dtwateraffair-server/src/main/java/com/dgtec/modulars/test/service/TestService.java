package com.dgtec.modulars.test.service;

import com.dgtec.modulars.base.service.BaseService;
import com.dgtec.modulars.test.vo.TestVO;

import java.util.List;

/**
 *  测试Service接口
 */
public interface TestService extends BaseService {

    /**
     *  查询用户列表
     * @return 用户列表
     */
    public List<TestVO> getUserList();

}
