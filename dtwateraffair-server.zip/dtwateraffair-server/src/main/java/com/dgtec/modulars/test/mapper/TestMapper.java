package com.dgtec.modulars.test.mapper;

import com.dgtec.modulars.test.entity.UserEntity;

import java.util.List;

/**
 * 测试Mapper
 */
public interface TestMapper {

    /**
     *  查询用户列表
     * @return 用户列表
     */
    public List<UserEntity> getUser();

}
