package com.dgtec.modulars.base.controller;

/**
 * 基础Controller
 * 本类中方法为公共方法
 */
public abstract class BaseController {

}
