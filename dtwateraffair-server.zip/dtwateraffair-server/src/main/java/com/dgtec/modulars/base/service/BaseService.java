package com.dgtec.modulars.base.service;

/**
 * 基础Service接口
 * 本类中方法为公共方法
 */
public interface BaseService {

}
