package com.dgtec.modulars.test.controller;

import com.dgtec.modulars.base.controller.BaseController;
import com.dgtec.modulars.test.service.TestService;
import com.dgtec.modulars.test.vo.TestVO;
import com.dgtec.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 测试Controller接口
 */

@RestController
@RequestMapping("/test")
public class TestController extends BaseController {

    @Autowired
    private TestService testService;

    /**
     * 查询用户信息列表
     * @return Result
     */
    @RequestMapping("/getUser")
    public Result getUser() {
        List<TestVO> userList = testService.getUserList();
        return Result.success(userList, userList.size());
    }

}
