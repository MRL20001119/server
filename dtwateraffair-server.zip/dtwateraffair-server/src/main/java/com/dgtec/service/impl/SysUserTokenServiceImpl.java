package com.dgtec.service.impl;

import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dgtec.entity.SysUserTokenEntity;
import com.dgtec.mapper.SysUserTokenMapper;
import com.dgtec.service.ISysUserTokenService;

@Service
public class SysUserTokenServiceImpl extends ServiceImpl<SysUserTokenMapper, SysUserTokenEntity> implements ISysUserTokenService {


}
