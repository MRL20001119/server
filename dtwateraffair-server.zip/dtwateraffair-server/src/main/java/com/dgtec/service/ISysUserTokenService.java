package com.dgtec.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dgtec.entity.SysUserTokenEntity;

/**
 * <p>
 * 系统用户Token 服务类
 * </p>
 *
 */
public interface ISysUserTokenService extends IService<SysUserTokenEntity> {

}
