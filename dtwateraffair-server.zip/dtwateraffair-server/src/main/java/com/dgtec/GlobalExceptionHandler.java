package com.dgtec;

import com.dgtec.utils.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * @ControllerAdvice 里的参数可以指定增强控制器要扫描的包，
 * 如果指定了包，就只捕获这个包抛出的异常，不指定，则捕获所有抛出的异常
 * @ControllerAdvice(basePackages="com.dgtec.system.controller")
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private final static Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // ⒈全局异常处理返回字符串
    @ExceptionHandler(PageException.class)
    @ResponseBody
    public String pageError(PageException e) {// 未知的异常做出响应
        logger.info("PageException", e);
        e.printStackTrace();
        return "PageError";
    }

    // ⒉全局异常处理返回JSON
    @ExceptionHandler(value = JsonException.class)
    @ResponseBody
    public Result jsonError(HttpServletRequest req, JsonException e) {

        logger.info("JsonException", e);
        e.printStackTrace();

        Result result = Result.failure(500, "JsonException");
        result.put("url", req.getRequestURL().toString());
        result.put("data", e.getData());

        return result;
    }


    // 4.全局异常处理返回json NullPointerException
    @ExceptionHandler(value = NullPointerException.class)
    @ResponseBody
    public Result nullPointerError(HttpServletRequest req, NullPointerException e) {
        logger.info("NullPointerException", e);
        e.printStackTrace();

        Result result = Result.failure();    //"空指针异常"
        result.put("url", req.getRequestURL().toString());
        result.put("exception", e);

        return result;
    }

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Result error(HttpServletRequest req, Exception e) {
        logger.info("UnknowException", e);
        e.printStackTrace();

        Result result = Result.failure(500, e.getMessage());
        result.put("url", req.getRequestURL().toString());

        return result;
    }

}