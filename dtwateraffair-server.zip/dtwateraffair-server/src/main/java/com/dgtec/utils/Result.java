package com.dgtec.utils;

//import org.apache.http.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 返回数据
 *
 * @author ge@nbdgtec.com
 */
@Component
public class Result extends HashMap<String, Object> {

	private static final long serialVersionUID = 1L;

	private static MessageSourceUtil messageSourceUtil = ApplicationContextUtil.getBean(MessageSourceUtil.class);

	@Autowired
	public Result() {
		put("status", 200);
		put("success", Boolean.TRUE);
		put("timestamp", System.currentTimeMillis());
	}
	
	public static Result failure() {
		return failure(HttpStatus.INTERNAL_SERVER_ERROR.value(), "unknown.error");//未知错误，请联系管理员
	}

	public static Result failure(String messageI18N) {
		return failure(HttpStatus.INTERNAL_SERVER_ERROR.value(), messageI18N);
	}

	/**
	 * I18N: Duplicate {0} code {1}
	 * @param messageI18N				eg: Duplicate {0} code {1}
	 * @param params					eg: ['菜单', 'menu']
	 * @return
	 */
	public static Result failure(String messageI18N, String[] params) {

		return failure(HttpStatus.INTERNAL_SERVER_ERROR.value(), messageI18N, params);
	}

	/**
	 *
	 * @param messageI18N				eg: Duplicate code [{0}]
	 * @param paramList					eg: ["menu","map"]
	 * @return
	 */
	public static Result failure(String messageI18N, List<String> paramList) {

		String[] params = new String[]{StringUtils.join(paramList, ",")};

		return failure(messageI18N, params);
	}

	public static Result failure(int status, String messageI18N) {
		String message = messageSourceUtil.getMessage(messageI18N);

		if (message == null || message.length() == 0)
			message = messageI18N;
		return failure(status, message, messageI18N);
	}

	public static Result failure(int status, String messageI18N, String[] params) {
		String message = messageSourceUtil.getMessage(messageI18N, params);
		if (message == null || message.length() == 0)
			message = messageI18N;
		return failure(status, message, messageI18N);
	}

	public static Result failure(int status, String message, String messageI18N) {
		Result r = new Result();
		r.put("status", status);
		r.put("success", Boolean.FALSE);
		r.put("message", message);
		r.put("messageI18N", messageI18N);
		return r;
	}

	public static Result success() {
		return new Result();
	}

	public static Result success(String messageI18N) {
		Result r = new Result();

		String message = messageSourceUtil.getMessage(messageI18N);
		if (message == null || message.length() == 0)
			message = messageI18N;

		r.put("message", message);
		r.put("messageI18N", messageI18N);
		return r;
	}

	public static Result success(Object value) {
		Result r = new Result();
		r.put("data", value);
		return r;
	}

	public static Result success(Object value, Number total) {
		Result r = new Result();
		r.put("data", value);
		r.put("total", total);
		return r;
	}

	public static Result success(Map<String, Object> map) {
		Result r = new Result();
		r.putAll(map);
		return r;
	}
	
	public Result put(String key, Object value) {
		super.put(key, value);
		return this;
	}
}
