package com.dgtec.system.service;

import com.dgtec.utils.Result;
import com.dgtec.system.model.SysLogSqlModel;

public interface SysLogSqlService {

    /**
     * 查找
     * @return
     */
    public Result findList(SysLogSqlModel model, Long current, Long limit);

}