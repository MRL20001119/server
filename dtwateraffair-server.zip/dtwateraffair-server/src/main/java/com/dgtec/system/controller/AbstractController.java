package com.dgtec.system.controller;

import com.dgtec.JsonException;
import com.dgtec.utils.LocaleUtils;
import com.dgtec.entity.SysUser;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.shiro.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Controller公共组件
 *
 */
public abstract class AbstractController {

	protected Logger logger = LoggerFactory.getLogger(getClass());
	
	protected SysUser getUser() {
		return (SysUser) SecurityUtils.getSubject().getPrincipal();
	}

	protected Integer getUserId() {
		return getUser().getId();
	}

	protected Integer getTenantId() {
		return getUser().getTenantId();
	}

	public ObjectMapper getJsonMapper() {

		ObjectMapper mapper=new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		return mapper;
	}

	/**
	 * 转换 json 字符串 为 常用字符串
	 * @param jsonString
	 * @return
	 * @throws IOException
	 */
	public String parseString(String jsonString) throws IOException {

		ObjectMapper mapper = getJsonMapper();

		return mapper.readValue(jsonString, String.class);
	}

	public void export(HttpServletResponse response, Object obj, String filename) throws Exception {

		ObjectMapper mapper=this.getJsonMapper();

		String str = null;
		try {
			str = mapper.writeValueAsString(obj);
		}
		catch (JsonProcessingException e) {
			throw new JsonException(LocaleUtils.get("AbstractController.illegal.JSON.format"));
		}

		InputStream is = new ByteArrayInputStream(str.getBytes());

		this.download(response, is, filename);
	}

	public void download(HttpServletResponse response, InputStream is, String filename) throws IOException {

		response.setContentType("octets/stream");
		response.addHeader("Content-Type", "text/html; charset=utf-8");
		response.addHeader("Content-Disposition", "attachment;filename=" + filename);

		this.write(response, is);
	}

	public void write(HttpServletResponse response, InputStream is) throws IOException {

		OutputStream os = response.getOutputStream();

		int i;
		byte[] b = new byte[1024];
		while ((i = is.read(b, 0, 1024)) != -1) {
			os.write(b, 0, i);
		}
		os.flush();
		os.close();
	}
}
