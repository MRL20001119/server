package com.dgtec.system.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dgtec.utils.Result;
import com.dgtec.entity.*;
import com.dgtec.mapper.*;
import com.dgtec.system.model.SysLogSqlModel;
import com.dgtec.system.service.SysLogSqlService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Transactional(readOnly = true)
@Component
public class SysLogSqlServiceImpl extends ServiceImpl<SysLogSqlMapper, SysLogSql> implements SysLogSqlService {

    @Autowired
    private SysLogSqlMapper sysLogSqlMapper;

    public Result findList(SysLogSqlModel model, Long current, Long limit) {

        Page<SysLogSql> page = this.sysLogSqlMapper.selectPage(new Page<>(current, limit),
                new QueryWrapper<SysLogSql>()
                        .eq(StringUtils.isNotBlank(model.getType()),"type", model.getType())
                        .like(StringUtils.isNotBlank(model.getName()),"name", model.getName())
                        .ge(model.getCreateTimeStart() != null,"create_time", model.getCreateTimeStart())
                        .lt(model.getCreateTimeEnd() != null,"create_time", model.getCreateTimeEnd())
                        .ge(model.getExecutedTimeFloor() != null,"executed_time", model.getExecutedTimeFloor())
                        .le(model.getExecutedTimeCeil() != null,"executed_time", model.getExecutedTimeCeil())
                        .orderByDesc("id")
        );

        return Result.success(page.getRecords(), page.getTotal());
    }

}