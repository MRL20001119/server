package com.dgtec.system.service;

import com.dgtec.utils.Result;
import com.dgtec.entity.SysRole;
import com.dgtec.entity.SysUser;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface UserService {

    SysUser getUserByUsername(String username);

    SysUser getUserById(Integer id);

    /**
     * 查找用户
     * @return
     */
    public Result findList(SysUser user, Long current, Long limit);

    /**
     * 查找下拉列表用户
     * @return
     */
    public Result findOptions(SysUser user);

    /**
     * 查找授权用户
     * @return
     */
    public List<SysUser> findListGrantRole(Integer tenantId, Integer roleId);

    Result insert(SysUser user);

    Result updateUserById(SysUser user);

    Result delete(List<Integer> idList);

    Map<String, List<Integer>> findAreaIdListGrantUserId(SysUser user);

    public List<String> findIntfPermissions2User(SysUser user);

  //  List<Integer> getPermissions(SysUser user);

    /**
     * 修改密码
     * @param userId       用户ID
     * @param password     原密码
     * @param newPassword  新密码
     */
    boolean updatePassword(Integer userId, String password, String newPassword, String salt);

    void removeUserRole(SysUser user);

    void insertUserRole(SysUser user, Collection<SysRole> roles);

}