package com.dgtec.system.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dgtec.utils.Result;
import com.dgtec.entity.SysRole;
import com.dgtec.entity.SysRoleMenu;
import com.dgtec.entity.SysUserRole;
import com.dgtec.mapper.SysRoleMapper;
import com.dgtec.mapper.SysRoleMenuMapper;
import com.dgtec.mapper.SysUserRoleMapper;
import com.dgtec.system.service.RoleService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Transactional(readOnly = true)
@Component
public class RoleServiceImpl implements RoleService {

    @Autowired
    private SysRoleMapper roleMapper;

    @Autowired
    private SysRoleMenuMapper roleMenuMapper;

    @Autowired
    private SysUserRoleMapper userRoleMapper;

    public Result findAll(SysRole role) {

        List<SysRole> list = this.roleMapper.selectList(
            new QueryWrapper<SysRole>()
                .eq(StringUtils.isNotBlank(role.getName()),"name", role.getName())
                .eq(role.getTenantId() != null,"tenant_id", role.getTenantId())
        );

        return Result.success(list, list.size());
    }

    public Result findList(SysRole role, Long current, Long limit) {

        Page<SysRole> page = this.roleMapper.selectPage(new Page<>(current, limit),
                new QueryWrapper<SysRole>()
                        .eq(StringUtils.isNotBlank(role.getName()),"name", role.getName())
                        .eq(role.getTenantId() != null,"tenant_id", role.getTenantId())
        );

        return Result.success(page.getRecords(), page.getTotal());
    }

    //@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void insertOne(SysRole role) {

        if (this.roleMapper.selectCount(new QueryWrapper<SysRole>()
                .eq("name", role.getName())
                .eq("tenant_id", role.getTenantId())
        ) >= 1)
            return;

        this.roleMapper.insert(role);
    }

    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public Result insert(SysRole role) {

        if (this.roleMapper.selectCount(new QueryWrapper<SysRole>()
            .eq("name", role.getName())
            .eq("tenant_id", role.getTenantId())
            ) >= 1)
            return Result.failure(1062, "code.duplicate");

        this.roleMapper.insert(role);

      //  redisTemplate.opsForValue().set("role:" + role.getId(), role);

        this.saveRoleMenu(role);
//        this.saveRolePermission(role);

        return new Result() {{
            this.put("data", role);
        }};
    }

    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public Result updateById(SysRole role) {

        if (this.roleMapper.selectCount(new QueryWrapper<SysRole>()
                .ne("id", role.getId())
                .eq("name", role.getName())
        ) >= 1)
            return Result.failure(1062, "code.duplicate");

        this.roleMapper.updateById(role);

//        redisTemplate.opsForValue().set("role:" + role.getId(), role);

        this.roleMenuMapper.deleteByRole(role);

        this.saveRoleMenu(role);
//        this.saveRolePermission(role);

        return new Result() {{
            this.put("data", role);
        }};
    }

    private void saveRoleMenu(SysRole role) {
        for (Integer menuId : role.getMenuIdList()) {
            SysRoleMenu rm = new SysRoleMenu();
            rm.setTriState(SysRole.SELECT_ALL);
            rm.setMenuId(menuId);
            rm.setRoleId(role.getId());
            this.roleMenuMapper.insert(rm);
        }
        for (Integer menuId : role.getMenuIdHalfList()) {
            SysRoleMenu rm = new SysRoleMenu();
            rm.setTriState(SysRole.SELECT_HALF);
            rm.setMenuId(menuId);
            rm.setRoleId(role.getId());
            this.roleMenuMapper.insert(rm);
        }
    }

    public Map<String, List<Integer>> findMenuIdListGrantRoleId(SysRole role) {

        Map<String, List<Integer>> map = new HashMap<>();

        if (role.getId() == null) {
            map.put("menuIdList", new ArrayList<>());
            map.put("menuIdHalfList", new ArrayList<>());
        }
        else {
            List<Integer> menuIdList = this.roleMenuMapper.findMenuIdListGrantRoleId(role.getId(), SysRole.SELECT_ALL);
            map.put("menuIdList", menuIdList);
            List<Integer> menuIdHalfList = this.roleMenuMapper.findMenuIdListGrantRoleId(role.getId(), SysRole.SELECT_HALF);
            map.put("menuIdHalfList", menuIdHalfList);
        }

        return map;
    }

    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public Result delete(List<Integer> idList) {

        if (idList.isEmpty())
            return Result.failure("role.notselect");

        if (this.userRoleMapper.selectCount(new QueryWrapper<SysUserRole>().in("role_id", idList)) >= 1)
            return Result.failure("role.binded");

      //  this.roleMenuMapper.deleteByRole().deleteBatchIds(idList);
//            redisTemplate.delete("role:" + idList);
        this.roleMapper.deleteBatchIds(idList);
//            redisTemplate.delete("role:" + idList);

        return Result.success("success.delete");
    }

    public Map<String, SysRole> findMap(Set<String> roleNames, Integer tenantId) {
        return this.roleMapper.findMap(roleNames, tenantId);
    }
}