package com.dgtec.system.controller;

import com.dgtec.utils.Result;
import com.dgtec.system.model.ExceptionLogModel;
import lombok.extern.log4j.Log4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.zip.GZIPInputStream;

@Controller
@RequestMapping(value="/log/exception")
public class ExceptionLogAction extends AbstractController {

	private final String ROOT = "d:" + File.separator + "log";


	/**
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/list", method = {RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	public Result findList(ExceptionLogModel model) {

		model.setPath(StringUtils.replace(model.getPath(), "/", File.separator));
		try {
			File file = new File(ROOT + model.getPath());
			if (file.isDirectory()) {
				List list = this.listFiles(file);
				return Result.success(list).put("path", model.getPath()).put("isPath", Boolean.TRUE);
			} else {
				StringBuilder content = this.fileContent(file);
				return Result.success(content).put("path", model.getPath()).put("isPath", Boolean.FALSE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return Result.failure().put("path", model.getPath());
	}

	/**
	 * 读取文件夹内容
	 */
	private List listFiles(File file) {
		List list = new ArrayList();
		int length = ROOT.length();

		File[] files = file.listFiles(new FileFilter() {
			@Override
			public boolean accept(File file) {
				return file.isDirectory() || file.getName().endsWith(".log") || file.getName().endsWith(".gz");
			}
		});

		Arrays.sort(files, new Comparator<File>() {
			@Override
			public int compare(File obj1, File obj2) {
				if (obj1.isDirectory() && obj2.isFile()) {
					return 1;
				} else if (obj1.isFile() && obj2.isDirectory()) {
					return -1;
				} else {
					return obj1.getName().compareTo(obj2.getName());
				}
			}
		});

		ExceptionLogModel exceptionLogModel;
		String path;
		for (File fileTmp : files) {
			exceptionLogModel = new ExceptionLogModel();
			list.add(exceptionLogModel);
			if (file.isDirectory())
				path = StringUtils.replace(fileTmp.getPath().substring(length), File.separator, "/");
			else
				path = StringUtils.replace(fileTmp.getParent().substring(length), File.separator, "/");
			exceptionLogModel.setPath(path);
			exceptionLogModel.setFilename(fileTmp.getName());
			if (fileTmp.isFile())
				exceptionLogModel.setFileSize(fileTmp.length());
			exceptionLogModel.setIsDirectory(fileTmp.isDirectory());
			exceptionLogModel.setCreateTime(getCreateTime(fileTmp));
			exceptionLogModel.setModifyTime(fileTmp.lastModified());
		}

		return list;
	}

	/**
	 * 读取文件内容
	 */
	private StringBuilder fileContent(File file){

		long pointer = 0; //上次文件大小

		StringBuilder builder = new StringBuilder();

		try {

			if (file.getName().endsWith(".gz")) {
				InputStream inputStream = new GZIPInputStream(new FileInputStream(file));
				Scanner sc = new Scanner(inputStream);
				List<String> lines = new ArrayList();
				while (sc.hasNextLine()) {
					builder.append(sc.nextLine()).append("\n");
				}
				sc.close();
				inputStream.close();
			}
			else {

				//指定文件可读可写
				RandomAccessFile randomFile = new RandomAccessFile(file, "r");

				randomFile.seek(pointer);//移动文件指针位置

				String tmp = "";
				while ((tmp = randomFile.readLine()) != null) {
					builder.append(new String(tmp.getBytes("ISO8859-1"), "UTF8")).append("\n");
					pointer = randomFile.getFilePointer();
				}

				randomFile.close();
			}
		} catch (IOException e) {

			builder.append(e.getMessage());
			e.printStackTrace();
		}

		return new StringBuilder(builder);
	}

	//下载流程定义
	@RequestMapping(value = "/download", method = {RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	public void download(HttpServletResponse response, ExceptionLogModel model) {

		model.setPath(StringUtils.replace(model.getPath(), "/", File.separator));
		File file = new File(ROOT + model.getPath());
		String filename = file.getName();

		try {
			InputStream inputStream = new FileInputStream(file);

			this.download(response, inputStream, filename);

			inputStream.close();
		}
		catch (IOException e) {
			logger.error("文件下载异常！", e);		//页面显示异常信息
		}
	}

	/**
	 * 读取文件创建时间
	 */
	private Long getCreateTime(File file){
		String strTime = null;
		try {

			BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);//获取bai

			return attr.creationTime().toMillis();
/*
			Process p = Runtime.getRuntime().exec("cmd /C dir " + file.getPath());
			InputStream is = p.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			String line;
			while((line = br.readLine()) != null){
				if(line.endsWith(".log")){
					strTime = line.substring(0,17);
					return DateUtils.stringToDate(strTime, "yyyy/MM/dd  HH:mm").getTime();
				}
			}*/
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

}