package com.dgtec.system.controller;

import com.dgtec.utils.Result;
import com.dgtec.entity.SysRole;
import com.dgtec.system.service.RoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/role")
//@CacheConfig(cacheNames = "role")
@Slf4j
public class RoleController extends AbstractController {

    @Autowired
    private RoleService roleService;

    /**
     *
     * 判断当前用户是否拥有删除流程权限
     *
     * @return
     */
//    @RequestMapping(value="/findAll", method={ RequestMethod.GET, RequestMethod.POST })
    @RequestMapping("/all")
    @ResponseBody
//    @Cacheable(cacheNames="role", key="'list'", cacheManager="cacheManager")       //key 需要内嵌一下单引号 不然会报错
    public Result findAll(SysRole role) {

        Integer tenantId = getTenantId();

        return this.roleService.findAll(role);

//        if (list.isEmpty())
//            throw new JsonException("JsonException controller");
//
//        return new Success(list, list.size());
    }

    /**
     *
     * 判断当前用户是否拥有删除流程权限
     *
     * @return
     */
//    @RequestMapping(value="/findAll", method={ RequestMethod.GET, RequestMethod.POST })
    @RequestMapping("/list")
    @ResponseBody
//    @Cacheable(cacheNames="role", key="'list'", cacheManager="cacheManager")       //key 需要内嵌一下单引号 不然会报错
    public Result findList(SysRole role,
                           @RequestParam(required = false, defaultValue = "1") Long current,
                           @RequestParam(required = false) Long limit) {

        Integer tenantId = getTenantId();

        return this.roleService.findList(role, current, limit);

//        if (list.isEmpty())
//            throw new JsonException("JsonException controller");
//
//        return new Success(list, list.size());
    }

    @RequestMapping("/save")
    @ResponseBody
//    @Cacheable(cacheNames="role", key="#role.id")
    public Result save(@RequestBody SysRole role) {

        role.setTenantId(getTenantId());
        if (role.getId() == null) {
            role.setStatus("1");        //正常
            return this.roleService.insert(role);
        }
        else
            return this.roleService.updateById(role);
    }

    /**
     * @param role
     * @return
     */
    @RequestMapping("/grantedIdList")
    @ResponseBody
//    @CachePut(cacheNames = "role", key = "list")
    public Map<String, List<Integer>> findMenuIdListGrantRoleId(@RequestBody SysRole role) {

        return this.roleService.findMenuIdListGrantRoleId(role);
    }

/*    @RequestMapping("/updateById")
    @ResponseBody
//    @CachePut(cacheNames = "role", key = "list")
    public Success updateById(@RequestParam("role") SysRoleEntity role) throws JsonException {

        if (role.getTenantId() != 1)
            throw new JsonException("");

        this.roleService.updateById(role);

        return new Success(role);
    }*/

    /**
     * @CacheEvict：缓存清除
     *  key：指定要清除的数据
     *  allEntries = true：指定清除这个缓存中所有的数据
     *  beforeInvocation = false：缓存的清除是否在方法之前执行
     *      默认代表缓存清除操作是在方法执行之后执行;如果出现异常缓存就不会清除
     *
     *  beforeInvocation = true：
     *      代表清除缓存操作是在方法运行之前执行，无论方法是否出现异常，缓存都清除
     *
     *
     */
    @RequestMapping("/delete")
    @ResponseBody
  //  @CacheEvict(cacheNames = "role", beforeInvocation = true, key = "#role.id")
    public Result deleteById(@RequestBody List<Integer> idList) {

        return this.roleService.delete(idList);
    }

}
