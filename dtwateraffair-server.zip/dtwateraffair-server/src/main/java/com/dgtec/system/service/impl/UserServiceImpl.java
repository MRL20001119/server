package com.dgtec.system.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dgtec.utils.Result;
import com.dgtec.entity.SysRole;
import com.dgtec.entity.SysUser;
import com.dgtec.entity.SysUserPermission;
import com.dgtec.entity.SysUserRole;
import com.dgtec.mapper.SysMenuMapper;
import com.dgtec.mapper.SysUserMapper;
import com.dgtec.mapper.SysUserPermissionMapper;
import com.dgtec.mapper.SysUserRoleMapper;
import com.dgtec.system.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Transactional(readOnly = true)
@Component
public class UserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements UserService {

    @Autowired
    private SysUserMapper userMapper;

    @Autowired
    private SysUserPermissionMapper userPermissionMapper;

    @Autowired
    private SysUserRoleMapper userRoleMapper;

    @Autowired
    private SysMenuMapper menuMapper;

    public SysUser getUserByUsername(String username) {
        return this.userMapper.getUserByUsername(username);
    }

    public SysUser getUserById(Integer id) {
        return this.userMapper.selectById(id);
    }

    public Result findList(SysUser user, Long current, Long limit) {

        //需要多表查询
        List<SysUser> list = this.userMapper.findList(user, (current-1l)*limit, limit);
//            redisTemplate.opsForList().leftPush("user:list", list);

        Integer count = this.userMapper.selectCount(
            new QueryWrapper<SysUser>()
                .eq(StringUtils.isNotBlank(user.getUsername()),"username", user.getUsername())
                .eq(user.getTenantId() != null,"tenant_id", user.getTenantId()));

        return Result.success(list, count);
    }

    public Result findOptions(SysUser user) {

        //需要多表查询
        List<SysUser> list = this.userMapper.selectList(
            new QueryWrapper<SysUser>()
                .select("id", "username")
                .eq(user.getTenantId() != null,"tenant_id", user.getTenantId()));
//            redisTemplate.opsForList().leftPush("user:list", list);

        return Result.success(list);
    }

    public List<SysUser> findListGrantRole(Integer tenantId, Integer roleId) {

        return this.userMapper.findListGrantRole(roleId, tenantId);
    }


    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public Result insert(SysUser user) {

        if (this.userMapper.selectCount(new QueryWrapper<SysUser>()
                .eq("username", user.getUsername())
        ) >= 1)
            return Result.failure(1062, "username.duplicate");

        this.userMapper.insert(user);

      //  redisTemplate.opsForValue().set("user:" + user.getId(), user);
        this.saveUserRole(user);
        this.saveUserPermission(user);

        return Result.success(user);
    }

    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public Result updateUserById(SysUser user) {

        if (this.userMapper.selectCount(new QueryWrapper<SysUser>()
                .ne("id", user.getId())
                .eq("username", user.getUsername())
        ) >= 1)
            return Result.failure(1062, "username.duplicate");

        this.userMapper.updateById(user);

        this.userRoleMapper.deleteByUser(user);
        this.userPermissionMapper.deleteByUser(user);

        this.saveUserRole(user);
        this.saveUserPermission(user);

    //    redisTemplate.opsForValue().set("permissions:user:" + user.getId(), user.getAreaIdList());

        return Result.success(user);
    }

    private void saveUserRole(SysUser user) {
        for (SysRole role : user.getRoleList()) {
            SysUserRole ur = new SysUserRole();
            ur.setUserId(user.getId());
            ur.setRoleId(role.getId());
            this.userRoleMapper.insert(ur);
        }
    }

    private void saveUserPermission(SysUser user) {
        for (Integer areaId : user.getAreaIdList()) {
            SysUserPermission up = new SysUserPermission();
            up.setUserId(user.getId());
            up.setAreaId(areaId);
            this.userPermissionMapper.insert(up);
        }
    }

    public Map<String, List<Integer>> findAreaIdListGrantUserId(SysUser user) {

        Map<String, List<Integer>> map = new HashMap<>();
        if (user.getId() ==null)
            map.put("areaIdList", new ArrayList<>());
        else {
            List<Integer> areaIdList = this.userPermissionMapper.findAreaIdListGrantUser(user);
            map.put("areaIdList", areaIdList);
        }

        return map;
    }

    public List<String> findIntfPermissions2User(SysUser user) {
        //获取数据权限
        List<Integer> areaIdList = this.userPermissionMapper.findAreaIdListGrantUser(user);
        //数据权限保存到redis缓存中
        //redisTemplate.opsForValue().set("permissions:user:" + user.getId(), areaIdList);
        //获取按钮权限并返回
        return this.menuMapper.findIntfPermissions2User(user);
    }

    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public Result delete(List<Integer> idList) {

        if (this.userMapper.deleteBatchIds(idList) > 0) {
            List<String> permissions = new ArrayList<>();
            for (Integer id : idList)
                permissions.add("permissions:user:" + id);

//            redisTemplate.delete(permissions);
//            return Result.success("success.delete");
        }

        return Result.success("success.delete");
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public boolean updatePassword(Integer userId, String password, String newPassword, String salt) {
        SysUser userEntity = new SysUser();
        userEntity.setPassword(newPassword);
        userEntity.setSalt(salt);
        return this.update(userEntity,
                new QueryWrapper<SysUser>().eq("id", userId).eq("password", password));
    }

    @Transactional(readOnly = false)
    public void removeUserRole(SysUser user) {
        this.userRoleMapper.deleteByUser(user);
    }

    @Transactional(readOnly = false)
    public void insertUserRole(SysUser user, Collection<SysRole> roles) {

        SysUserRole sur;
        for (SysRole role : roles) {
            sur = new SysUserRole();
            sur.setUserId(user.getId());
            sur.setRoleId(role.getId());
            this.userRoleMapper.insert(sur);
        }
    }
}