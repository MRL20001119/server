package com.dgtec.system.service;

import com.dgtec.entity.SysUser;
import com.dgtec.system.model.Menu;

import java.util.List;

public interface MenuService {

    public List<Menu> findAll2Tenant(Integer tenantId);

    public List<Menu> findAll2User(SysUser user, Integer[] nodeProps);

    public void saveAll(List<Menu> list, Integer tenantId);

}