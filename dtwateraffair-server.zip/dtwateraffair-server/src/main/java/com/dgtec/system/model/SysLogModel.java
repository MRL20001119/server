package com.dgtec.system.model;

import lombok.Data;

import java.io.Serializable;


/**
 * 系统日志
 *
 * @author ge@nbdgtec.com
 */
@Data
public class SysLogModel implements Serializable {

	private static final long serialVersionUID = 1L;

	//用户名
	private String username;

	//IP地址
	private String ip;

	//servlet path
	private String uri;

	//结果状态
	private String status;

	//sqlId
	private String name;

	//sql类型
	private String type;

	//创建时间
	private Long createTimeStart;

	//创建时间
	private Long createTimeEnd;

	//执行时长(毫秒)
	private Long executedTimeFloor;

	//执行时长(毫秒)
	private Long executedTimeCeil;

	public void setCreateTimeEnd(Long createTimeEnd) {
		if (createTimeEnd != null)
			this.createTimeEnd = createTimeEnd + 86400000l;
	}
}
