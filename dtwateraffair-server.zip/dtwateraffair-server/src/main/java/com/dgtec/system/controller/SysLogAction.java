package com.dgtec.system.controller;

import com.dgtec.utils.Result;
import com.dgtec.system.model.SysLogModel;
import com.dgtec.system.service.SysLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value="/log")
public class SysLogAction extends AbstractController {

	@Autowired
	SysLogService sysLogService;

	/**
	 * @param model
	 * @param current
	 * @param limit
	 * @return
	 */
	@RequestMapping(value = "/list", method = {RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	public Result findList(SysLogModel model,
				   @RequestParam(required = false, defaultValue = "1") Long current,
				   @RequestParam(required = false) Long limit) {

		Boolean onlyLogin = false;
		return this.sysLogService.findList(onlyLogin, model, current, limit);
	}

	/**
	 * @param model
	 * @param current
	 * @param limit
	 * @return
	 */
	@RequestMapping(value = "/login/list", method = {RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	public Result findLoginList(SysLogModel model,
						   @RequestParam(required = false, defaultValue = "1") Long current,
						   @RequestParam(required = false) Long limit) {

		Boolean onlyLogin = true;
		return this.sysLogService.findList(onlyLogin, model, current, limit);
	}

}