package com.dgtec.system.controller;

import com.dgtec.utils.Result;
import com.dgtec.entity.SysUser;
import com.dgtec.system.model.Menu;
import com.dgtec.system.service.MenuService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/menu")
@Slf4j
public class MenuController extends AbstractController {

    @Autowired
    private MenuService menuService;

    /**
     *
     * 获取租户的全部菜单
     *
     * @return
     */
    @RequestMapping("/all")
    @ResponseBody
    public List<Menu> findAll() {

        SysUser user = this.getUser();

        if (user.getUsername().equals("admin") && user.getTenantId()==1)
            return this.menuService.findAll2Tenant(null);

        return this.menuService.findAll2Tenant(user.getTenantId());
    }

    /**
     *
     * 获取全部菜单
     *
     * @return
     */
//    @RequestMapping("/all")
//    @ResponseBody
//    public List<Menu> findAll() {
//
//        SysUser user = this.getUser();
//
//        if (user.getUsername().equals("admin") && user.getTenantId()==1)
//            return this.menuService.findAll(null, null);
//
//        return this.menuService.findAll(user, null);
//    }

    /**
     *
     * 获取用户的授权菜单
     *
     * @return
     */
    @RequestMapping("/list")
    @ResponseBody
    public List<Menu> findMenues(@RequestBody Integer[] nodeProps) {

        SysUser user = this.getUser();

        return this.menuService.findAll2User(user, nodeProps);
    }

    /**
     * 重新保存全部菜单
     * @param list
     * @return
     */
    @RequestMapping("/saveAll")
    @ResponseBody
    public Result saveAll(@RequestBody ArrayList<Menu> list) {

        if (list.isEmpty())
            return Result.failure("menu.required");

        Integer tenantId = getTenantId();

        Set<String> codeSet = new HashSet<>();
        List<String> dupList = new ArrayList<>();
        for (Menu menu : list) {
            menu.setTenantId(tenantId);
            if (menu.getNodeProp() == null || menu.getNodeProp().equals("3"))
                continue;
            if (codeSet.contains(menu.getCode()))
                dupList.add(menu.getCode());
            else
                codeSet.add(menu.getCode());
        }

        if (!dupList.isEmpty()) {
            return Result.failure("codes.duplicate", dupList);
        }

        this.menuService.saveAll(list, tenantId);

        return Result.success(list, list.size());
    }

    /**
     *
     * 导出系统菜单
     *
     * @return
     */
    @RequestMapping("/export")
    @ResponseBody
    public void export(HttpServletResponse response) throws Exception {

        String filename = "Menu" + Instant.now().getEpochSecond() + ".json";

        List<Menu> list = this.findAll();

        this.export(response, list, filename);
    }

}
