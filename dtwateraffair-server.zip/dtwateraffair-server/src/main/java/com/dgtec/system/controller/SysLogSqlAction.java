package com.dgtec.system.controller;

import com.dgtec.utils.Result;
import com.dgtec.system.model.SysLogSqlModel;
import com.dgtec.system.service.SysLogSqlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value="/log/sql")
public class SysLogSqlAction extends AbstractController {

	@Autowired
	SysLogSqlService sysLogSqlService;

	/**
	 * @param model
	 * @param current
	 * @param limit
	 * @return
	 */
	@RequestMapping(value = "/list", method = {RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	public Result findList(SysLogSqlModel model,
				   @RequestParam(required = false, defaultValue = "1") Long current,
				   @RequestParam(required = false) Long limit) {

		return this.sysLogSqlService.findList(model, current, limit);
	}

}