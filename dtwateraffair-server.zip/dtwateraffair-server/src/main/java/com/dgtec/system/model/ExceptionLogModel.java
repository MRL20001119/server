package com.dgtec.system.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.File;
import java.io.Serializable;


/**
 * 异常日志
 *
 * @author ge@nbdgtec.com
 */
@Data
public class ExceptionLogModel implements Serializable {

	private static final long serialVersionUID = 1L;

	//目录
	private String path = File.separator;

	//文件名
	private String filename;

	//文件名
	private Long fileSize;

	//文件目录
	private Boolean isDirectory;

	//创建时间
	private Long createTime;

	//创建时间
	@JsonIgnore
	private Long createTimeStart;

	//创建时间
	@JsonIgnore
	private Long createTimeEnd;

	//修改时间
	private Long modifyTime;

	//修改时间
	@JsonIgnore
	private Long modifyTimeStart;

	//修改时间
	@JsonIgnore
	private Long modifyTimeEnd;

	public void setCreateTimeEnd(Long createTimeEnd) {
		if (createTimeEnd != null)
			this.createTimeEnd = createTimeEnd + 86400000l;
	}

	public void setModifyTimeEnd(Long modifyTimeEnd) {
		if (modifyTimeEnd != null)
			this.modifyTimeEnd = modifyTimeEnd + 86400000l;
	}
}
