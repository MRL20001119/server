package com.dgtec.system.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class Menu implements Serializable {

    /**
     * ID
     * ID
     */
    private Integer id;

    /**
     * 编号
     * CODE
     */
    private String code;

    /**
     * 名称
     * NAME
     */
    @JsonProperty("label")
    private String name;

    /**
     * 父菜单
     * PARENT_ID
     */
    private Integer parentId;

    /**
     * 状态   1:有效； 2:作废
     * STATUS
     */
    private String status;

    /**
     * 节点性质     1:菜单; 2:资源; 3:接口
     * NODE_TYPE
     */
    private String nodeProp;

    /**
     * 资源类别/接口类别
     * RES_TYPE
     */
    @JsonProperty("type")
    private String type;

    /**
     * 路由地址
     * ROUTE
     */
    @JsonProperty("path")
    private String route;

    /**
     * 组件地址
     * FILE_PATH
     */
    @JsonProperty("filePath")
    private String filePath;

    /**
     * 层次
     * LEVEL
     */
    private Integer level;

    /**
     * 本级中菜单顺序
     * INDEX
     */
    private Integer index;

    /**
     * 节点图标
     * ICON
     */
    private String icon;

    /**
     * 客户
     * TENANT_ID
     */
    private Integer tenantId;

}
