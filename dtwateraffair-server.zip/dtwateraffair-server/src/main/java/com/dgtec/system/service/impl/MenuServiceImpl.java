package com.dgtec.system.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dgtec.entity.SysRoleMenu;
import com.dgtec.entity.SysUser;
import com.dgtec.mapper.SysMenuMapper;
import com.dgtec.mapper.SysRoleMenuMapper;
import com.dgtec.system.model.Menu;
import com.dgtec.system.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Transactional(readOnly = true)
@Component
public class MenuServiceImpl implements MenuService {

    @Autowired
    private SysMenuMapper menuMapper;

    @Autowired
    private SysRoleMenuMapper roleMenuMapper;


    public List<Menu> findAll2Tenant(Integer tenantId) {

        return this.menuMapper.findAll2Tenant(tenantId);
    }

    public List<Menu> findAll2User(SysUser user, Integer[] nodeProps) {

        return this.menuMapper.findAll2User(user, nodeProps);
    }

    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void saveAll(List<Menu> list, Integer tenantId) {

        Integer maxId = this.menuMapper.getMaxId();
        this.menuMapper.deleteAll(tenantId);
        for (Menu record : list) {
            if (record.getId().intValue() > maxId.intValue())
                maxId = record.getId();
        }

        Map<Integer, Integer> map = new HashMap<>();
        Map<Integer, Integer> map2 = new HashMap<>();
        Set<Integer> set = new HashSet<>();
        for (Menu record : list) {
            if (record.getParentId() == null)
                record.setParentId(0);

            if (record.getId().intValue() < 0) {
                map.put(record.getId(), ++maxId);
                record.setId(maxId);

                //父节点id 大于0(非新建)，需要把role_menu中id对应的全选标志修改成半选标志
                if (record.getParentId().intValue() > 0)
                    set.add(record.getParentId());
                if (map.containsKey(record.getParentId())) {
                    //修改初始父节点ID为入库节点
                    record.setParentId(map.get(record.getParentId()));
                }
            }
            else {
                map2.put(record.getId(), record.getParentId());
            }

            this.menuMapper.insert(record);
        }

        Set<Integer> set2 = new HashSet<>();
        for (Integer pid : set) {
            do {
                set2.add(pid);
                pid = map2.get(pid);
            }
            while (pid.intValue() != 0);
        }

        for (Integer pid : set2) {
            SysRoleMenu roleMenu = new SysRoleMenu();
            roleMenu.setTriState("1");
            this.roleMenuMapper.update(roleMenu,
                    new QueryWrapper<SysRoleMenu>().eq("menu_id", pid).eq("tri_State", "2"));
        }
    }

}