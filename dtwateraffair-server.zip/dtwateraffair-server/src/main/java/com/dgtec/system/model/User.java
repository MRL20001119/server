package com.dgtec.system.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;

@Data
public class User implements Serializable {

    /**
     * 用户ID
     * USER_ID
     */
    private Integer id;

    /**
     * 用户名
     * USERNAME
     */
    private String username;

    /**
     * 姓名
     * NAME
     */
    private String name;

    /**
     * 密码
     * PASSWORD
     */
    @JsonIgnore
    private String password;

    /**
     * 盐值
     * SALT
     */
    @JsonIgnore
    private String salt;

    /**
     * 电子邮箱
     * EMAIL
     */
    @JsonIgnore
    private String email;

    /**
     * 手机号
     * MOBILE
     */
    @JsonIgnore
    private String mobile;

    /**
     * 状态
     * STATUS
     */
    @JsonIgnore
    private String status;

    /**
     * 创建时间
     * CREATE_TIME
     */
    @JsonIgnore
    private Long createTime;

    /**
     * 租户ID
     * TENANT_ID
     */
    @JsonIgnore
    private Integer tenantId;

}
