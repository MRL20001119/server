package com.dgtec.system.controller;

import com.dgtec.aop.OperationLogDetail;
import com.dgtec.utils.Result;
import com.dgtec.utils.ShiroUtil;
import com.dgtec.entity.SysRole;
import com.dgtec.entity.SysUser;
import com.dgtec.system.model.CloudModel;
import com.dgtec.system.model.LoginModel;
import com.dgtec.system.service.RoleService;
import com.dgtec.system.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;

//import org.springframework.data.redis.core.StringRedisTemplate;

@RestController
@Slf4j
public class LoginController {

//    private final static Logger logger = LoggerFactory.getLogger(LoginController.class);
//    private static Logger logger = Logger.getLogger(LoginController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

//    @Autowired
//    private SysCaptchaService sysCaptchaService;

//	/**
//	 * 验证码
//	 */
//	@RequestMapping(value="/captcha.jpg", method=RequestMethod.GET)
////    @Cacheable(cacheNames="login", key="#uuid")
//	public void captcha(HttpServletResponse response, String uuid) throws IOException {
//		response.setHeader("Cache-Control", "no-store, no-cache");
//		response.setContentType("image/jpeg");
//
//		//获取图片验证码
//		BufferedImage image = sysCaptchaService.getCaptcha(uuid);
//
//		ServletOutputStream out = response.getOutputStream();
//		ImageIO.write(image, "jpg", out);
//        out.close();
//	}

    //注解验角色和权限
    //注解方式缓存返回值，登录方法结果无需缓存
    @OperationLogDetail(name="登录")
    @RequestMapping(value="/login", method=RequestMethod.POST)
//    @Cacheable(value="login", key="#model.uuid", cacheManager="cacheManager")        //key为字符串时，需要内嵌单引号 不然会报错
    @ResponseBody
    public Result login(@RequestBody LoginModel model) {

//        boolean valid = sysCaptchaService.validate(model.getUuid(), model.getCaptcha());
//        if(!valid){
//            return Result.failure(500, "permission.captchaInvalid");
//        }

        String username = model.getUsername();
        String password = model.getPassword();

        AuthenticationToken token
                = new UsernamePasswordToken(username, password);

        ShiroUtil.login(token);

        return Result.success().put("token", ShiroUtil.getSubject().getSession().getId());
    }

    //注解验角色和权限
    //注解方式缓存返回值，登录方法结果无需缓存
    @OperationLogDetail(name="云平台登录")
    @RequestMapping(value="/logini", method=RequestMethod.POST)
//    @Cacheable(value="login", key="#model.uuid", cacheManager="cacheManager")        //key为字符串时，需要内嵌单引号 不然会报错
    @ResponseBody
    public Result logini(@RequestBody CloudModel model) {

        this.syncLogin(model);

        //从云确认jsession有效
        String username = model.getUsername();
        String password = model.getSystem();
        AuthenticationToken token
                = new UsernamePasswordToken(username, password);

        ShiroUtil.login(token);

        return Result.success().put("token", ShiroUtil.getSubject().getSession().getId());

    }

    //注解验角色和权限
    //注解方式缓存返回值，登录方法结果无需缓存
    @OperationLogDetail(name="云平台登录")
//    @RequestMapping(value="/logine", method={RequestMethod.GET, RequestMethod.POST})
//    @Cacheable(value="login", key="#model.uuid", cacheManager="cacheManager")        //key为字符串时，需要内嵌单引号 不然会报错
    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    public void syncLogin(CloudModel model) {

        model.setTenantId(1);

        //从云确认jsession有效
        String username = model.getUsername();
        String xname = model.getName();
        String password = model.getSystem();

        SysUser user = this.userService.getUserByUsername(username);
        if (user == null) {
            user = new SysUser();
            user.setUsername(username);
            user.setName(xname);
            String salt = RandomStringUtils.randomAlphanumeric(16);
            password = ShiroUtil.sha256(password, salt);          //SHA-256
            user.setSalt(salt);
            user.setPassword(password);
            user.setTenantId(model.getTenantId());
            user.setStatus(1);
            user.setRoleList(new ArrayList<>());
            user.setAreaIdList(new ArrayList<>());
            this.userService.insert(user);
        }
        else {
            String salt = user.getSalt();
            password = ShiroUtil.sha256(password, salt);          //SHA-256
            this.userService.updatePassword(user.getId(), user.getPassword(), password, salt);
        }

        model.getRoles().add("ROLE_SUPER_ADMIN");
        Map<String, SysRole> srMap = this.roleService.findMap(model.getRoles(), model.getTenantId());
        Set<String> labelSet = srMap.keySet();
        Set<String> cloudRoleSet = new HashSet(model.getRoles());
        cloudRoleSet.removeAll(labelSet);

        List<SysRole> srl = new ArrayList<>();
        for (String name : cloudRoleSet) {
            SysRole sr = new SysRole();
            srl.add(sr);

            sr.setLabel(name);
            sr.setName(name);
            sr.setStatus("1");
            sr.setTenantId(model.getTenantId());

            this.roleService.insertOne(sr);
        }

        srMap = this.roleService.findMap(model.getRoles(), model.getTenantId());

        this.userService.removeUserRole(user);
        this.userService.insertUserRole(user, srMap.values());
    }

    @RequiresRoles("admin")
    @RequiresPermissions("list")
    @RequestMapping(value="/index", method=RequestMethod.GET)
    public String index() {
        return "index!";
    }

    @OperationLogDetail(name="注销")
    @RequestMapping(value="/logout", method=RequestMethod.GET)
    @ResponseBody
//    @CrossOrigin(origins = "http://localhost:8080", maxAge = 3600)
    public Result logout(HttpServletRequest request, HttpServletResponse response) {
//        HttpSession session = request.getSession();
//        User user = (User) session.getAttribute(session.getId());
//        String pticket = user.getPticket();
//        String url = OPSConstants.OPS_URL_LOGOUT + "&pticket=" + pticket;

        ShiroUtil.logout();

        return Result.success("permission.logoutSuccess");
    }

    @RequestMapping("/noauth")
    public Result noauth() {

        return Result.failure(401, "permission.token.expired");
    }

    @RequestMapping("/403")
    public Result p403() {

        return Result.failure(403, "permission.unauthorized"); //未授权
    }

    @RequestMapping(value="/changeLang", method=RequestMethod.GET)
    @ResponseBody
    public void changeLang() { }

    //12小时后过期
    private final static int EXPIRE = 3600 * 12;

    public String generateToken(String... strings) {
        StringBuilder token = new StringBuilder("token:");
        for (String s : strings) {
            token.append(s);
        }
        token.append(System.currentTimeMillis());
        return DigestUtils.md5DigestAsHex(token.toString().getBytes());
    }

}