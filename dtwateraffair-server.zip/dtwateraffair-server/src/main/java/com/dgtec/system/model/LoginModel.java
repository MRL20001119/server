package com.dgtec.system.model;

import lombok.Data;

/**
 * 登录表单
 *
 */
@Data
public class LoginModel {

    private String username;

    private String password;

//    private String captcha;

    private String uuid;

}
