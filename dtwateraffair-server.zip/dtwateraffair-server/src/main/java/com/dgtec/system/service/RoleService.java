package com.dgtec.system.service;

import com.dgtec.utils.Result;
import com.dgtec.entity.SysRole;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface RoleService {

    public Result findAll(SysRole role);

    public Result findList(SysRole role, Long current, Long limit);

    void insertOne(SysRole role);

    Result insert(SysRole role);

    Result updateById(SysRole role);

    Map<String, List<Integer>> findMenuIdListGrantRoleId(SysRole role);

    Result delete(List<Integer> idList);

    Map<String, SysRole> findMap(Set<String> roleNames, Integer tenantId);
}