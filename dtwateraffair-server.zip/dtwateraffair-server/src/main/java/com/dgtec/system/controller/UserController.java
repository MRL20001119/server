package com.dgtec.system.controller;

import com.dgtec.utils.Result;
import com.dgtec.utils.ShiroUtil;
import com.dgtec.entity.SysRole;
import com.dgtec.entity.SysUser;
import com.dgtec.system.model.PasswordModel;
import com.dgtec.system.model.User;
import com.dgtec.system.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
//@CacheConfig(cacheNames = "user")
@Slf4j
public class UserController extends AbstractController {

    @Autowired
    private UserService userService;

    /**
     *
     * 判断当前用户是否拥有删除流程权限
     *
     * @return
     */
//    @RequestMapping(value="/findAll", method={ RequestMethod.GET, RequestMethod.POST })
    @RequestMapping("/list")
    @ResponseBody
//    @Cacheable(cacheNames="user", key="'list'", cacheManager="cacheManager")       //key 需要内嵌一下单引号 不然会报错
    public Result findList(@RequestBody SysUser user,
               @RequestParam(required = false, defaultValue = "1") Long current,
               @RequestParam(required = false) Long limit) {

        user.setTenantId(this.getTenantId());
        return this.userService.findList(user, current, limit);
    }

    /**
     *
     * 判断当前用户是否拥有删除流程权限
     *
     * @return
     */
    @RequestMapping(value="/options", method={ RequestMethod.GET })
//    @RequestMapping("/options")
    @ResponseBody
//    @Cacheable(cacheNames="user", key="'list'", cacheManager="cacheManager")       //key 需要内嵌一下单引号 不然会报错
    public Result findOptions(SysUser user) {

        user.setTenantId(this.getTenantId());
        return this.userService.findOptions(user);
    }

    @RequestMapping("/grantedList")
    @ResponseBody
//    @Cacheable(cacheNames="user", key="'list'", cacheManager="cacheManager")       //key 需要内嵌一下单引号 不然会报错
    public Result findListGrantRole(@RequestBody SysRole role) {
        Integer tenantId = getTenantId();
        List<SysUser> list = this.userService.findListGrantRole(tenantId, role.getId());

        return Result.success(list, list.size());
    }

//    @RequestMapping("/user")
//    @ResponseBody
////    @Cacheable(cacheNames="user", key="#user.id")
//    public Success addUser(@RequestParam("user") SysUser user) throws JsonException {
//
//        return this.userService.findList(user, 0, 20);
//    }

    @RequestMapping("/save")
    @ResponseBody
//    @Cacheable(cacheNames="role", key="#role.id")
    public Result save(@RequestBody SysUser user) {

        if (user.getId() == null) {
            user.setTenantId(getTenantId());
//            String salt = user.getUsername() + "!#act";
            String salt = generateRandomString();
            user.setSalt(salt);
            String password = ShiroUtil.sha256(user.getPassword(), salt);          //SHA-256
            user.setPassword(password);

            return this.userService.insert(user);
        }
        else
            return this.userService.updateUserById(user);
    }

    /**
     * @param user
     * @return
     */
    @RequestMapping("/grantedIdList")
    @ResponseBody
//    @CachePut(cacheNames = "role", key = "list")
    public Map<String, List<Integer>> findAreaIdListGrantUserId(@RequestBody SysUser user) {

        //  if (role.getTenantId() != 1)
        //      throw new JsonException("");

        return this.userService.findAreaIdListGrantUserId(user);

        //return new Success(role);
    }

//    @RequestMapping("/updateUserById")
//    @ResponseBody
////    @CachePut(cacheNames = "user", key = "list")
//    public Success updateUserById(@RequestParam("user") SysUser user) throws JsonException {
//        List<SysUser> list = this.userService.findList(user, 0, 20);
//
//        if (list.isEmpty())
//            throw new JsonException("JsonException controller", user);
//
//        return new Success(list, list.size());
//    }

    /**
     * 重置用户密码
     */
    @RequestMapping(value="/password", method=RequestMethod.POST)
    @ResponseBody
//    @CachePut(cacheNames = "user", key = "list")
    public Result resetPassword(@RequestBody SysUser user) {


//		Assert.isBlank(model.getNewPassword(), "新密码不为能空");
        if (user.getPassword() == null)
            return Result.failure("新密码不为能空");

        //sha256加密
        String password = user.getPassword();

        user = this.userService.getUserById(user.getId());
        if (user == null)
            return Result.failure("未找到用户");

        String salt = generateRandomString();

        user.setSalt(salt);
        //sha256加密
        String newPassword = ShiroUtil.sha256(password, salt);

        //更新密码
        boolean success = userService.updatePassword(user.getId(), user.getPassword(), newPassword, salt);
        if(!success){
            return Result.failure("原密码不正确");
        }

        return Result.success();
    }

    /**
     * @CacheEvict：缓存清除
     *  key：指定要清除的数据
     *  allEntries = true：指定清除这个缓存中所有的数据
     *  beforeInvocation = false：缓存的清除是否在方法之前执行
     *      默认代表缓存清除操作是在方法执行之后执行;如果出现异常缓存就不会清除
     *
     *  beforeInvocation = true：
     *      代表清除缓存操作是在方法运行之前执行，无论方法是否出现异常，缓存都清除
     *
     *
     */
    @RequestMapping("/delete")
    @ResponseBody
//    @CacheEvict(cacheNames = "user", beforeInvocation = true, key = "#user.id")
    public Result deleteById(@RequestBody List<Integer> idList) {
//        this.
//        if (this.getUser().getId().equals(user.getId()))
//            return Result.failure("manager.delete.forbidden");

        if (idList.contains(this.getUser().getId()))
            return Result.failure("forbidden.current.delete");

        return this.userService.delete(idList);
    }

    /**
     *
     * 获取当前用户的个人信息和按钮权限以及数据权限
     *
     * @return
     */
    @RequestMapping("/info")
    @ResponseBody
//    @Cacheable(cacheNames="user", key="'info'", cacheManager="cacheManager")       //key 需要内嵌一下单引号 不然会报错
    public Result getUserInfo() {
        SysUser userEntity = (SysUser)ShiroUtil.getSubject().getPrincipal();

        User user = new User();
        user.setId(userEntity.getId());
        user.setUsername(userEntity.getUsername());
        user.setName(userEntity.getName());
        user.setEmail(userEntity.getEmail());
        user.setMobile(userEntity.getMobile());

        List<String> intfPermissions = this.userService.findIntfPermissions2User(userEntity);    //获取按钮权限

        Map<String, Object> map = new HashMap();
        map.put("user", user);
        map.put("intfPermissions", intfPermissions);

        return Result.success(map);
    }


	/**
	 * 修改登录用户密码
	 */
    @RequestMapping(value="/updatePassword", method=RequestMethod.POST)
    @ResponseBody
//    @CachePut(cacheNames = "user", key = "list")
    public Result updatePassword(@RequestBody PasswordModel model) {


//		Assert.isBlank(model.getNewPassword(), "新密码不为能空");

        //sha256加密
        String salt = getUser().getSalt();
        String password = ShiroUtil.sha256(model.getPassword(), salt);

        //sha256加密
        salt = generateRandomString();
        String newPassword = ShiroUtil.sha256(model.getNewPassword(), salt);

        //更新密码
        boolean success = userService.updatePassword(getUserId(), password, newPassword, salt);
        if(!success){
            return Result.failure("原密码不正确");
        }

        SysUser userEntity = (SysUser)ShiroUtil.getSubject().getPrincipal();
        userEntity.setSalt(salt);

        return Result.success("密码已修改");
    }

    private String generateRandomString() {
        return RandomStringUtils.randomAlphanumeric(16);
    }

}
