package com.dgtec.system.service;

import com.dgtec.utils.Result;
import com.dgtec.system.model.SysLogModel;

public interface SysLogService {

    /**
     * 查找
     * @return
     */
    public Result findList(Boolean onlyLogin, SysLogModel model, Long current, Long limit);

}