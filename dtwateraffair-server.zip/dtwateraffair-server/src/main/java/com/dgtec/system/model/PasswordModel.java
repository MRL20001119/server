package com.dgtec.system.model;

import lombok.Data;

/**
 * 密码表单
 *
 */
@Data
public class PasswordModel {

    /**
     * 原密码
     */
    private String password;

    /**
     * 新密码
     */
    private String newPassword;

}
