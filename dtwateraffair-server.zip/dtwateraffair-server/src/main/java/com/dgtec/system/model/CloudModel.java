package com.dgtec.system.model;

import lombok.Data;

import java.util.List;
import java.util.Set;

/**
 * 登录表单
 *
 */
@Data
public class CloudModel {

    private String username;

    private String password;

    private String system;

    private String name;

    private Set<String> roles;

    private Integer tenantId;

}
