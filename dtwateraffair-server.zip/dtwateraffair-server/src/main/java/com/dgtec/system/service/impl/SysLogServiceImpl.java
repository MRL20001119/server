package com.dgtec.system.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dgtec.utils.Result;
import com.dgtec.entity.SysLog;
import com.dgtec.mapper.SysLogMapper;
import com.dgtec.system.model.SysLogModel;
import com.dgtec.system.service.SysLogService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
@Component
public class SysLogServiceImpl extends ServiceImpl<SysLogMapper, SysLog> implements SysLogService {

    @Autowired
    private SysLogMapper sysLogMapper;

    public Result findList(Boolean onlyLogin, SysLogModel model, Long current, Long limit) {

        Page<SysLog> page = this.sysLogMapper.selectPage(new Page<>(current, limit),
            new QueryWrapper<SysLog>()
                .in(onlyLogin && StringUtils.isBlank(model.getUri()), "uri", "/login", "/logini", "/logout")
                .eq(onlyLogin && StringUtils.isNotBlank(model.getUri()),"uri", model.getUri())
                .like(!onlyLogin && StringUtils.isNotBlank(model.getUri()),"uri", model.getUri())
                .eq(StringUtils.isNotBlank(model.getUsername()),"username", model.getUsername())
                .eq(StringUtils.isNotBlank(model.getStatus()),"status", model.getStatus())
                .ge(model.getCreateTimeStart() != null,"create_time", model.getCreateTimeStart())
                .lt(model.getCreateTimeEnd() != null,"create_time", model.getCreateTimeEnd())
                .ge(model.getExecutedTimeFloor() != null,"executed_time", model.getExecutedTimeFloor())
                .le(model.getExecutedTimeCeil() != null,"executed_time", model.getExecutedTimeCeil())
                .orderByDesc("id")
        );

        return Result.success(page.getRecords(), page.getTotal());
    }

}