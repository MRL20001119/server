package com.dgtec.system.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;


/**
 * 系统日志
 *
 * @author ge@nbdgtec.com
 */
@Data
public class SysLogSqlModel implements Serializable {

	private static final long serialVersionUID = 1L;

	//sqlId
	private String name;

	//sql类型
	private String type;

	//创建时间
	private Long createTimeStart;

	//创建时间
	private Long createTimeEnd;

	//执行时长(毫秒)
	private Long executedTimeFloor;

	//执行时长(毫秒)
	private Long executedTimeCeil;

	public void setCreateTimeEnd(Long createTimeEnd) {
		if (createTimeEnd != null)
			this.createTimeEnd = createTimeEnd + 86400000l;
	}
}
