package com.dgtec.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

/**
 * 系统用户
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_user")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SysUser implements Serializable {
	private static final long serialVersionUID = 1L;
	
	/**
	 * 用户ID
	 */
	@TableId(value="id", type=IdType.AUTO)
	private Integer id;

	/**
	 * 用户名
	 */
	@NotBlank(message="用户名不能为空")
	private String username;

	/**
	 * 姓名
	 */
	private String name;

	/**
	 * 密码
	 */
	@NotBlank(message="密码不能为空")
	private String password;

	/**
	 * 盐
	 */
	private String salt;

	/**
	 * 邮箱
	 */
	@Email(message="邮箱格式错误")
	private String email;

	/**
	 * 手机号
	 */
	private String mobile;

	/**
	 * 状态  0：禁用   1：正常
	 */
	private Integer status;

	/**
	 * 角色名称列表
	 */
	@TableField(exist=false)
	private List<SysRole> roleList;

	/**
	 * 角色名称列表
	 */
	@TableField(exist=false)
	private List<Integer> areaIdList;

	/**
	 * 创建时间
	 */
	private Long createTime;

	/**
	 * 失效日期
	 */
	private Long expiredTime;
	/**
	 * 客户ID
	 */
	private Integer tenantId;

}
