package com.dgtec.entity;

import java.io.Serializable;
import java.sql.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;


/**
 * 系统用户Token
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_user_token")
public class SysUserTokenEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	// id
	@TableId(type = IdType.INPUT)
	private Long id;

	// token
	private String token;
	
	private String session;

	// 过期时间
	private Date expireTime;

	// 更新时间
	private Date updateTime;

}
