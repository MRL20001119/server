package com.dgtec.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;


/**
 * 系统日志
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_log")
public class SysLog implements Serializable {

	private static final long serialVersionUID = 1L;

	@TableId(value="id", type=IdType.AUTO)
	private Long id;

	//用户名
	private String username;

	//IP地址
	private String ip;

	//请求方法
	private String method;

	//请求方法
	private String uri;

	//用户操作
	@TableField(value="user_agent")
	private String userAgent;

	//请求参数
	private String args;

	//请求参数
	@TableField(value="return_value")
	private String returnValue;

	//创建时间
	@TableField(value="create_time")
	private Long createTime;

	//执行时长(毫秒)
	@TableField(value="executed_time")
	private Long executedTime;

	//执行时长(毫秒)
	private String level;

	//执行时长(毫秒)
	private Integer line;

	//结果状态
	private String status;

}
