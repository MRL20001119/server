package com.dgtec.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;


/**
 * 系统日志
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_log_sql")
public class SysLogSql implements Serializable {

	private static final long serialVersionUID = 1L;

	@TableId
	private Long id;

	//sqlId
	private String name;

	//sql
	private String msg;

	//sql类型
	private String type;

	//创建时间
	@TableField(value="create_time")
	private Long createTime;

	//执行时长(毫秒)
	@TableField(value="executed_time")
	private Long executedTime;

}
