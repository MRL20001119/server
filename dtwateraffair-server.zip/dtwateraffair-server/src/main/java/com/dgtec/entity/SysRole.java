package com.dgtec.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

/**
 * 角色
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_role")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SysRole implements Serializable {
	private static final long serialVersionUID = 1L;

	public static final String SELECT_HALF = "1";

	public static final String SELECT_ALL = "2";

	/**
	 * 角色ID
	 */
	@TableId(value="id", type=IdType.AUTO)
	private Integer id;

	/**
	 * 角色名称
	 */
	@NotBlank(message="角色名称不能为空")
	private String name;

	/**
	 * 标签
	 */
	@NotBlank(message="标签不能为空")
	private String label;

	/**
	 * 备注
	 */
	private String remark;

	/**
	 * 租户
	 */
	private Integer tenantId;

	/**
	 * 状态
	 */
	private String status;

	/**
	 * 全选菜单
	 */
	@TableField(exist=false)
	private List<Integer> menuIdList;

	/**
	 * 半选菜单
	 */
	@TableField(exist=false)
	private List<Integer> menuIdHalfList;

	/**
	 * 数据权限
	 */
	@TableField(exist=false)
	private List<Integer> areaIdList;

	@TableField(exist=false)
	private List<Integer> userIdList;

}
