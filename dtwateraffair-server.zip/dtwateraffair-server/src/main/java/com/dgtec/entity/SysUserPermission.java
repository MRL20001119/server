package com.dgtec.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户与区域对应关系
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_user_permission")
public class SysUserPermission implements Serializable {

	private static final long serialVersionUID = 1L;

	@TableId(value="id", type=IdType.AUTO)
	private Long id;

	/**
	 * 用户ID
	 */
	private Integer userId;

	/**
	 * 区域ID
	 */
	private Integer areaId;

}
