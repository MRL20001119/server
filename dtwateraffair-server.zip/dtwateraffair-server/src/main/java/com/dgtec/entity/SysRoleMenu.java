package com.dgtec.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * 角色与菜单对应关系
 *
 * @author ge@nbdgtec.com
 */
@Data
@TableName("sys_role_menu")
public class SysRoleMenu implements Serializable {

	private static final long serialVersionUID = 1L;

	@TableId(value="id", type=IdType.AUTO)
	private Long id;

	/**
	 * 角色ID
	 */
	private Integer roleId;

	/**
	 * 菜单ID
	 */
	private Integer menuId;

	/**
	 * 选中状态, 0:不选; 1:半选; 2:全选
	 */
	private String triState;

}
