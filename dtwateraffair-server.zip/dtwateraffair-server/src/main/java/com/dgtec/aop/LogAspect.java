package com.dgtec.aop;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.dgtec.entity.SysUser;
import com.dgtec.system.model.CloudModel;
import com.dgtec.system.model.LoginModel;
import com.dgtec.utils.IpUtil;
import com.dgtec.utils.Result;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

/**
 * Created by IntelliJ IDEA
 *
 * @date 2020/10/11
 */
@Log4j2
@Aspect
@Component
public class LogAspect {

    @Autowired
    HttpServletRequest request;

    /**
     * 此处的切点是注解的方式，也可以用包名的方式达到相同的效果
     * '@Pointcut("execution(* com.wwj.springboot.service.impl.*.*(..))")'
     * '@Pointcut("@annotation(com.dgtec.aop.OperationLogDetail)")'
     */
    @Pointcut("execution(* com.dgtec.*.controller.*.*(..))")
    public void operationLog(){}


    /**
     * 环绕增强，相当于MethodInterceptor
     */
    @Around("operationLog()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        Object returnValue = null;
        Long start = System.currentTimeMillis(), executedTime = null;

        MDC.put("username", "anonymous");
        SysUser user = (SysUser) SecurityUtils.getSubject().getPrincipal();
        if (user != null)
            MDC.put("username", user.getUsername());

        try {
            returnValue =  joinPoint.proceed();
            executedTime = System.currentTimeMillis() - start;
            return returnValue;
        } finally {
            try {
                user = (SysUser) SecurityUtils.getSubject().getPrincipal();
                if (user != null)
                    MDC.put("username", user.getUsername());

                //方法执行完成后增加日志
                insertOperationLog(joinPoint, returnValue, start, executedTime);
            }catch (Exception e){
                log.info("操作失败：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void insertOperationLog(JoinPoint joinPoint, Object returnValue, Long start, long executedTime) throws IllegalArgumentException, JsonProcessingException{

        //    HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Object[] args = joinPoint.getArgs();
        if (request.getServletPath().equals("/login")) {
            LoginModel model = (LoginModel)args[0];
            MDC.put("username", model.getUsername());
        }
        else if (request.getServletPath().equals("/logini")) {
            CloudModel model = (CloudModel)args[0];
            MDC.put("username", model.getUsername());
        }

        MethodSignature signature = (MethodSignature)joinPoint.getSignature();

        MDC.put("ip", IpUtil.getIp(request));
        MDC.put("uri", request.getServletPath());
        MDC.put("method", request.getMethod());
        MDC.put("user_agent", request.getHeader("User-Agent"));
        MDC.put("create_time", start + "");
        MDC.put("executed_time", executedTime + "");

        List argList = new ArrayList();
        for (Object arg : args) {
            if (arg instanceof ServletResponse
                    || arg instanceof ServletRequest
                    || arg instanceof MultipartFile)
                continue;

            argList.add(arg);
        }
        ObjectMapper objMapper = new ObjectMapper();
//        MDC.put("args", JSON.toJSONString(argList));
        MDC.put("args", objMapper.writeValueAsString(argList));
        MDC.put("success", "true");
        if (returnValue != null) {
            if (returnValue instanceof Result) {
                Result res = (Result) returnValue;
                if (res.containsKey("success"))
                    MDC.put("success", res.get("success").toString());
            }
        }

        log.info("执行耗时 : [" + executedTime + "ms ]");
    }

    @Before("operationLog()")
    public void doBeforeAdvice(JoinPoint joinPoint){
//        System.out.println("进入方法前执行.....");

    }

    /**
     * 处理完请求，返回内容
     * @param ret
     */
    @AfterReturning(returning = "ret", pointcut = "operationLog()")
    public void doAfterReturning(Object ret) {
//        System.out.println("方法的返回值 : " + ret);
    }

    /**
     * 后置异常通知
     */
    @AfterThrowing("operationLog()")
    public void throwss(JoinPoint jp){
//        System.out.println("方法异常时执行.....");
    }


    /**
     * 后置最终通知,final增强，不管是抛出异常或者正常退出都会执行
     */
    @After("operationLog()")
    public void after(JoinPoint jp){
//        System.out.println("方法最后执行.....");
    }

}