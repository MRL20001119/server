package com.dgtec.aop;

import java.lang.annotation.*;

/**
 * Created by IntelliJ IDEA
 *
 * @date 2020/10/11
 */
//@OperationLogDetail(detail = "通过手机号[{{tel}}]获取用户名",level = 3,operationUnit = OperationUnit.USER,operationType = OperationType.SELECT)
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface OperationLogDetail {

    /**
     * 方法描述,可使用占位符获取参数:{{tel}}
     */
    String name() default "";

    /**
     * 日志等级:自己定，此处分为1-9
     */
    int level() default 0;

}