package com.dgtec;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class RunScript implements CommandLineRunner{
    private final static Logger logger = LoggerFactory.getLogger(RunScript.class);
    
	@PreDestroy
	public void destory() {
		logger.info("程序关闭...");
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("程序启动...");
		
	}
}
