package com.dgtec.config;

import java.io.Serializable;
import java.util.List;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.eis.EnterpriseCacheSessionDAO;
import org.apache.shiro.subject.support.DefaultSubjectContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dgtec.entity.SysUserTokenEntity;
import com.dgtec.service.ISysUserTokenService;
import com.dgtec.utils.ApplicationContextUtil;
import com.dgtec.utils.SerializableUtils;

public class DtCacheSessionDAO extends EnterpriseCacheSessionDAO {
	
	Logger logger = LoggerFactory.getLogger(DtCacheSessionDAO.class);
	
    ISysUserTokenService tokenService;
    
    public DtCacheSessionDAO() {
    	super();
    }
	
    private void initTokenService() {
    	if(this.tokenService == null) {
    		this.tokenService = ApplicationContextUtil.getBean(ISysUserTokenService.class);
    	}
    }
    
	@Override
    protected Serializable doCreate(Session session) {
        // 如果doRead方法中没有读取到session则会进入这个方法来创建一个session
        Serializable cookie = super.doCreate(session);
        // 以下注释如果打开的话会将所有的session都存放到数据库,包括没有认证的session
       /* ClientSession entity = new ClientSession(cookie.toString(), SerializableUtils.serializ(session));
        sessionService.save(entity);*/
        logger.info("创建Session" + cookie);
        return cookie;
    }

    @Override
    protected Session doReadSession(Serializable sessionId) {
        logger.info("读取session" + sessionId);
        Session memSession = null;
        try {
        	// 先从内存中读取session
            memSession = super.doReadSession(sessionId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // 如果内存中读取不到,则从数据库中读取session
        if (memSession == null) {
        	initTokenService();
        	QueryWrapper<SysUserTokenEntity> wrapper = new QueryWrapper<>();
        	wrapper.eq("token", sessionId.toString());
        	List<SysUserTokenEntity> sessionList = this.tokenService.list(wrapper);
        	
        	//如果数据库中可以读取到,则返回数据库中读取到的session
            if (sessionList != null && !sessionList.isEmpty()) {
                memSession = SerializableUtils.deserializ(sessionList.get(sessionList.size() - 1).getSession());
            }
        }
        return memSession;
    }

    @Override
    protected void doUpdate(Session session) {
    	// 1.先从数据库获取session
    	SysUserTokenEntity clientSession = null;
    	initTokenService();
    	
    	QueryWrapper<SysUserTokenEntity> wrapper = new QueryWrapper<>();
    	wrapper.eq("token", session.getId().toString());
    	List<SysUserTokenEntity> sessionList = this.tokenService.list(wrapper);
    	if (sessionList != null && !sessionList.isEmpty()) {
    		clientSession = sessionList.get(0);
    	}
    	
    	// 2.如果可以获取到session则更新,这样会导致每次有请求过来都会更新,因为请求的时间不一致,session中的时间会随着请求的时间变化
        if (clientSession != null) {
            clientSession.setSession(SerializableUtils.serializ(session));
            this.tokenService.updateById(clientSession);
            logger.info("更新数据库中的session:" + clientSession.getToken());
        } else {
        	// 3.如果获取不到session,并且session已经通过认证,则将session保存到数据库
            Object obj = session.getAttribute(DefaultSubjectContext.AUTHENTICATED_SESSION_KEY);
            if (obj != null) {
                String attribute = obj.toString();
                if (Boolean.parseBoolean(attribute)) {
                    logger.info("已经认证session,存入数据库!" + session.getId());
                    SysUserTokenEntity entity = new SysUserTokenEntity();
                    entity.setSession(SerializableUtils.serializ(session));
                    entity.setToken(session.getId().toString());
                    this.tokenService.save(entity);
                }
            }
        }
        super.doUpdate(session);
    }

    @Override
    protected void doDelete(Session session) {
    	initTokenService();
    	QueryWrapper<SysUserTokenEntity> wrapper = new QueryWrapper();
    	wrapper.eq("token", session.getId());
    	this.tokenService.remove(wrapper);
        super.doDelete(session);
    }
    
}
