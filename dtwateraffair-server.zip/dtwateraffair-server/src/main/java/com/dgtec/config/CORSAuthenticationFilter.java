package com.dgtec.config;

import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.util.StringUtils;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.apache.shiro.web.util.WebUtils;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description
 */
public class CORSAuthenticationFilter extends FormAuthenticationFilter {

    public CORSAuthenticationFilter() {
        super();
    }

    /**
     * 生成自定义token
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) {
        //获取请求token
        String token = getRequestToken((HttpServletRequest) request);
        if (!StringUtils.hasLength(token)) {
            return null;
        }
        return new AuthToken(token);
    }

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        if(request instanceof HttpServletRequest) {
            if (((HttpServletRequest) request).getMethod().equals(RequestMethod.OPTIONS.name())) {
                HttpServletResponse res = (HttpServletResponse) response;
                res.setHeader("Access-Control-Allow-Origin", "*");


                return true;
            }
        }

        return super.isAccessAllowed(request, response, mappedValue);
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
//        //获取请求token，如果token不存在，直接返回
//        String token = getRequestToken((HttpServletRequest) request);
//        if (!StringUtils.hasLength(token)) {
//            HttpServletResponse res = (HttpServletResponse) response;
//            res.setHeader("Access-Control-Allow-Origin", "*");          //允许全部域名跨域，可以指定特点域名，逗号分隔
//            res.setHeader("Access-Control-Allow-Credentials", "true");  //允许携带cookie
////            res.setHeader("Access-Control-Allow-Headers", "X-Requested-With"); //允许传输的请求头
////            res.setHeader("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS"); //允许发送的xhr模式
////            res.setHeader("X-Powered-By", " 3.2.1"); //快速模式
////            res.setHeader("Content-Type", "application/json;charset=utf-8"); //类型及字符编码
//
//            res.setStatus(HttpServletResponse.SC_OK);
//            res.setCharacterEncoding("UTF-8");
//            res.setContentType("text/html; charset=utf-8");
//            PrintWriter writer = res.getWriter();
//            Map<String, Object> map = new HashMap<>();
////            map.put("status", 400);
            WebUtils.toHttp(response).sendError(HttpServletResponse.SC_UNAUTHORIZED);
//            map.put("msg", "登录错误");
//            writer.write(JSON.toJSONString(map));
//            writer.close();
            return false;
//        }
//        return executeLogin(request, response);
    }

    /**
     * 获取请求的token
     */
    private String getRequestToken(HttpServletRequest httpRequest) {

        //从header中获取token
        String token = httpRequest.getHeader("token");
        //如果header中不存在token，则从参数中获取token
        if (!StringUtils.hasLength(token)) {
            token = httpRequest.getParameter("token");
        }
        return token;
    }
}