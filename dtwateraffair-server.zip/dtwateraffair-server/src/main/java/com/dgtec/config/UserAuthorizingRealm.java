package com.dgtec.config;

import com.dgtec.utils.ShiroUtil;
import com.dgtec.entity.SysUser;
import com.dgtec.mapper.SysUserMapper;
import com.dgtec.system.model.User;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class UserAuthorizingRealm extends AuthorizingRealm {

    private final static Logger logger = LoggerFactory.getLogger(UserAuthorizingRealm.class);

    @Autowired
    private SysUserMapper sysUserMapper;

    /**
     * 授权验证，获取角色权限信息
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        User user = (User) principalCollection.getPrimaryPrincipal();
        List<String> perms;
        // 系统管理员拥有最高权限
//        if (User.SUPER_ADMIN == user.getId()) {
//            perms = loginService.getAllPerms();
//        } else {
//            perms = loginService.getUserPerms(user.getId());
//        }
//
//        // 权限Set集合
        Set<String> permsSet = new HashSet<>();
//        for (String perm : perms) {
//            permsSet.addAll(Arrays.asList(perm.trim().split(",")));
//        }

        permsSet.add("admin");

        // 返回权限
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.setStringPermissions(permsSet);
        return info;
    }

    /**
     * 登录验证，获取用户凭证信息
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        // 获取用户
        SysUser user = sysUserMapper.getUserByUsername(token.getUsername());
        if (user == null) {
            throw new UnknownAccountException("账号或密码有误");
        }

        String password = new String(token.getPassword());
        String salt = user.getSalt();

        // 验证密码
//        if (password.length() == 32) {    //云平台免密码登录
//            token.setPassword(user.getPassword().toCharArray());
//        }
//        else {
            password = ShiroUtil.sha256(password, salt);     //SHA-256

            if (!user.getPassword().equals(password)) {
                throw new IncorrectCredentialsException("凭证无效");
            }
//        }

//        // 判断用户是否被锁定
//        if (user.getStatus() == null || user.getStatus() == 1) {
//            throw new LockedAccountException("账号已被锁定,请联系管理员");
//        }

//        user.setSessionId(SecurityUtils.getSubject().getSession().getId().toString());

        ByteSource byteSource = ByteSource.Util.bytes(salt);

        // 持久化用户的登录信息
        // 设置最后登录时间
//        user.setLastLoginTime(new Date());

        return new SimpleAuthenticationInfo(user, password, byteSource, getName());
    }

    @Override
    public void setCredentialsMatcher(CredentialsMatcher credentialsMatcher) {
        HashedCredentialsMatcher shaCredentialsMatcher = new HashedCredentialsMatcher();

        shaCredentialsMatcher.setHashAlgorithmName(ShiroUtil.hashAlgorithmName);     //SHA-256
//        shaCredentialsMatcher.setHashAlgorithmName(ShiroUtils.md5);                     //md5

        shaCredentialsMatcher.setHashIterations(ShiroUtil.hashIterations);
        super.setCredentialsMatcher(shaCredentialsMatcher);
    }
}
