package com.dgtec.dtwateraffairserver;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MybatisPlusTest {

//    @Autowired
//    private UserPlusMapper userPlusMapper;
//
//    @Test
//    public void testSelectOne() {
//        User user = userPlusMapper.selectById(1L);
//        System.out.println(user);
//    }
//
//    @Test
//    public void testInsert() {
//        User user = new User();
//        user.setUsername("smile");
//        user.setCode("3");
//        user.setPassword("neo@tooool.org");
//        assertThat(userPlusMapper.insert(user)).isGreaterThan(0);
//        assertThat(user.getId()).isNotNull();   // 成功直接拿回写的 ID
//    }
//
//    @Test
//    public void testDelete() {
//        assertThat(userPlusMapper.deleteById(3L)).isGreaterThan(0);
//        assertThat(userPlusMapper.delete(new QueryWrapper<User>()
//                .lambda().eq(User::getUsername, "smile"))).isGreaterThan(0);
//    }
//
//    @Test
//    public void testUpdate() {
//        User user = userPlusMapper.selectById(4);
//        assertThat(user.getCode()).isEqualTo("coolish");
//        assertThat(user.getUsername()).isEqualTo("cool");
//
//        userPlusMapper.update(
//                null,
//                Wrappers.<User>lambdaUpdate().set(User::getPassword, "123@123").eq(User::getId, 4)
//        );
//        assertThat(userPlusMapper.selectById(4).getPassword()).isEqualTo("123@123");
//    }
//
//    @Test
//    public void testSelect() {
//        List<User> userList = userPlusMapper.selectList(null);
//        Assert.assertEquals(3, userList.size());
//        userList.forEach(System.out::println);
//    }
//
//    @Test
//    public void testSelectByUsername() {
//        String username = "libai";
//        User user = userPlusMapper.getUserByUsername(username);
//        assertThat(user).isNotNull();
//        assertThat(user.getId()).isNotNull();
//        Assert.assertEquals(2, user.getId().intValue());
//
//    }
//
//    @Test
//    public void testSelectCondition() {
//        QueryWrapper<User> wrapper = new QueryWrapper<>();
//        wrapper.select("max(sus_id) as id");
//        List<User> userList = userPlusMapper.selectList(wrapper);
//        userList.forEach(System.out::println);
//    }
//
//    @Test
//    public void testPage() {
//        System.out.println("----- baseMapper 自带分页 ------");
//        Page<User> page = new Page<>(1, 2);
//        IPage<User> userIPage = userPlusMapper.selectPage(page, new QueryWrapper<User>()
//                .gt("sus_id", 1));
//        assertThat(page).isSameAs(userIPage);
//        System.out.println("总条数 ------> " + userIPage.getTotal());
//        System.out.println("当前页数 ------> " + userIPage.getCurrent());
//        System.out.println("当前每页显示数 ------> " + userIPage.getSize());
//        print(userIPage.getRecords());
//        System.out.println("----- baseMapper 自带分页 ------");
//    }
//
//    private <T> void print(List<T> list) {
//        if (!CollectionUtils.isEmpty(list)) {
//            list.forEach(System.out::println);
//        }
//    }


}
