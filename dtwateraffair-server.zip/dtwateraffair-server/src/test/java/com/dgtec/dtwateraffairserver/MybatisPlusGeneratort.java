package com.dgtec.dtwateraffairserver;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.po.TableFill;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;


public class MybatisPlusGeneratort {

    // TODO 根据实际情况修改
    private final static String FILE_PATH = "E:\\Git\\dtwateraffair-server\\src\\test\\templates";

    // TODO 根据实际情况修改
    private final static String TARGET_TABLE = "dma_info";

    private final static DbType DB_TYPE = DbType.MYSQL;

    private final static String DB_DRIVER = "com.mysql.jdbc.Driver";

    private final static String DB_URL = "jdbc:mysql://192.168.3.196:3306/wateraffair";

    private final static String DB_USER = "root";

    private final static String DB_PSD = "root";

    @Test
    public void generateTest() {
        //全局配置
        GlobalConfig config = new GlobalConfig();
        //设置是否支持AR模式
        config.setActiveRecord(true)
                //设置生成代码的作者
                .setAuthor("admin")
                //设置输出代码的位置
                .setOutputDir(FILE_PATH)
                //.setEnableCache(false)// XML 二级缓存
                //.setBaseResultMap(true)// XML ResultMap
                //.setBaseColumnList(true)// XML columList
                //.setKotlin(true) 是否生成 kotlin 代码
                //设置是否覆盖原来的代码
                .setFileOverride(true);

        //******************************数据源配置***************************************
        //数据库连接url
        String dbUrl = DB_URL;
        //数据源配置
        DataSourceConfig dataSourceConfig = new DataSourceConfig();
        //数据库类型 枚举
        dataSourceConfig.setDbType(DB_TYPE)
                //设置url
                .setUrl(dbUrl)
                //设置用户名
                .setUsername(DB_USER)
                //设置密码
                .setPassword(DB_PSD)
                //设置数据库驱动
                .setDriverName(DB_DRIVER);
//                // 自定义数据库表字段类型转换【可选】
//                .setTypeConvert(new MySqlTypeConvert() {
//                    @Override
//                    public DbColumnType processTypeConvert(GlobalConfig globalConfig, String fieldType) {
//                        System.out.println("转换类型：" + fieldType);
//                        //tinyint转换成Boolean
//                        if (fieldType.toLowerCase().contains("tinyint")) {
//                            return DbColumnType.BOOLEAN;
//                        }
//                        //将数据库中datetime转换成date
//                        if (fieldType.toLowerCase().contains("datetime")) {
//                            return DbColumnType.DATE;
//                        }
//                        return (DbColumnType) super.processTypeConvert(globalConfig, fieldType);
//                    }
//                });

        //******************************策略配置******************************************************
        // 自定义需要填充的字段 数据库中的字段
        List<TableFill> tableFillList = new ArrayList<>();
//        tableFillList.add(new TableFill("gmt_modified", FieldFill.INSERT_UPDATE));
//        tableFillList.add(new TableFill("modifier_id", FieldFill.INSERT_UPDATE));
//        tableFillList.add(new TableFill("creator_id", FieldFill.INSERT));
//        tableFillList.add(new TableFill("gmt_creat", FieldFill.INSERT));
//        tableFillList.add(new TableFill("available_flag", FieldFill.INSERT));
//        tableFillList.add(new TableFill("deleted_flag", FieldFill.INSERT));
//        tableFillList.add(new TableFill("sync_flag", FieldFill.INSERT));
        //策略配置
        StrategyConfig strategyConfig = new StrategyConfig();
        strategyConfig
                //全局大写命名是否开启
                .setCapitalMode(true)
                //【实体】是否为lombok模型
                .setEntityLombokModel(true)
                //表名生成策略 下划线转驼峰
                .setNaming(NamingStrategy.underline_to_camel)
                //自动填充设置
                .setTableFillList(tableFillList).setEntityTableFieldAnnotationEnable(true)
                //修改替换成你需要的表名，多个表名传数组
                .setInclude(TARGET_TABLE);
        //集成注入设置
        //注入全局设置
        new AutoGenerator().setGlobalConfig(config)
                //注入数据源配置
                .setDataSource(dataSourceConfig)
                //注入策略配置
                .setStrategy(strategyConfig)
                //设置包名信息
                .setPackageInfo(
                        new PackageConfig()
                                //提取公共父级包名
                                .setParent("com.dgtec")
                                //设置实体类信息
                                .setEntity("entity")
                )
                //设置自定义模板
                .setTemplate(
                        new TemplateConfig()
                                //.setXml(null)//指定自定义模板路径, 位置：/resources/templates/entity2.java.ftl(或者是.vm)
                                //注意不要带上.ftl(或者是.vm), 会根据使用的模板引擎自动识别
                                // 自定义模板配置，模板可以参考源码 /mybatis-plus/src/main/resources/template 使用 copy
                                // 至您项目 src/main/resources/template 目录下，模板名称也可自定义如下配置：
                                 .setController(null)
//                                 .setEntity("")
//                                 .setMapper("")
                                 .setXml(null)
//                                 .setService(null)
//                                .setServiceImpl(null)
                )
                //开始执行代码生成
                .execute();
    }

}
