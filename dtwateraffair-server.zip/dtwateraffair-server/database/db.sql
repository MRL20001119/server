--
-- Create schema wateraffair
--

CREATE DATABASE IF NOT EXISTS wateraffair;
USE wateraffair;

-- set global max_allowed_packet = 2*1024*1024*10


DROP TABLE IF EXISTS `sys_captcha`;
CREATE TABLE `sys_captcha` (
  `uuid` char(36) NOT NULL COMMENT 'uuid',
  `code` varchar(6) NOT NULL COMMENT '验证码',
  `expire_time` datetime default NULL COMMENT '过期时间',
  PRIMARY KEY  (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统验证码';



DROP TABLE IF EXISTS `sys_company`;
CREATE TABLE `sys_company` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sys_company` (`id`,`name`) VALUES
 (1,'东海集团');



DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` bigint(20) NOT NULL auto_increment,
  `param_key` varchar(50) default NULL COMMENT 'key',
  `param_value` varchar(2000) default NULL COMMENT 'value',
  `status` tinyint(4) default '1' COMMENT '状态   0：隐藏   1：显示',
  `remark` varchar(500) default NULL COMMENT '备注',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `param_key` (`param_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统配置信息表';

INSERT INTO sys_config (id, param_key, param_value, status, remark) VALUES (1, 'CLOUD_STORAGE_CONFIG_KEY', '{"aliyunAccessKeyId":"","aliyunAccessKeySecret":"","aliyunBucketName":"","aliyunDomain":"","aliyunEndPoint":"","aliyunPrefix":"","qcloudBucketName":"","qcloudDomain":"","qcloudPrefix":"","qcloudSecretId":"","qcloudSecretKey":"","qiniuAccessKey":"NrgMfABZxWLo5B-YYSjoE8-AZ1EISdi1Z3ubLOeZ","qiniuBucketName":"ios-app","qiniuDomain":"http://7xqbwh.dl1.z0.glb.clouddn.com","qiniuPrefix":"upload","qiniuSecretKey":"uIwJHevMRWU0VLxFvgy0tAcOdGqasdtVlJkdy6vV","type":1}', 0, '');


DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(50) default NULL COMMENT '用户名',
  `ip` varchar(64) default NULL COMMENT 'IP地址',
  `method` varchar(45) default NULL,
  `uri` varchar(200) default NULL,
  `user_agent` varchar(200) NOT NULL COMMENT '用户操作',
  `args` varchar(5000) default NULL COMMENT '请求参数',
  `return_value` varchar(5000) default NULL COMMENT '执行时长(毫秒)',
  `create_time` bigint(20) unsigned default NULL COMMENT '创建时间',
  `executed_time` bigint(20) unsigned default NULL COMMENT '耗时',
  `level` varchar(45) NOT NULL,
  `line` int(10) unsigned default NULL,
  `status` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='系统日志';

DROP TABLE IF EXISTS `sys_log_sql`;
CREATE TABLE `sys_log_sql` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `name` varchar(200) default NULL,
  `type` varchar(45) default NULL,
  `msg` varchar(5000) default NULL,
  `create_time` bigint(20) default NULL,
  `executed_time` bigint(20) default NULL,
  PRIMARY KEY  USING BTREE (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` bigint(20) NOT NULL auto_increment,
  `parent_id` bigint(20) default NULL COMMENT '父菜单ID，一级菜单为0',
  `name` varchar(200) default NULL COMMENT '菜单名称',
  `route` varchar(200) default NULL COMMENT '菜单URL',
  `node_prop` tinyint(3) unsigned default NULL COMMENT '授权(多个用逗号分隔，如：user:list,user:create)',
  `type` tinyint(3) unsigned default NULL COMMENT '类型   0：目录   1：菜单   2：按钮',
  `icon` varchar(200) default NULL COMMENT '菜单图标',
  `index_` int(10) unsigned default NULL COMMENT '排序',
  `code` varchar(200) default NULL,
  `status` tinyint(3) unsigned default NULL,
  `level` int(10) unsigned default NULL,
  `tenant_id` int(10) unsigned default NULL,
  `file_path` varchar(200) default NULL COMMENT '组件地址',
  PRIMARY KEY  USING BTREE (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54757 DEFAULT CHARSET=utf8 COMMENT='菜单管理';

INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (2660, 3041, '菜单设置', '/menu', 2, 1, null, 1, 'menu', 1, 3, 1, '/views/system/Menu');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (2668, 3041, '用户管理', '/user', 2, 1, null, 3, 'user', 1, 3, 1, '/views/system/User');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (2672, 3041, '角色管理', '/role', 2, 1, null, 2, 'role', 1, 3, 1, '/views/system/Role');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (3040, 0, '系统平台', null, 1, null, null, 1, 'sysform', 1, 1, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (3041, 3040, '系统管理', null, 1, null, null, 1, 'system', 1, 2, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (3043, 3040, '日志管理', null, 1, null, null, 2, 'business', 1, 2, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (3045, 3040, '地图管理', null, 1, null, null, 3, 'mapManagement', 1, 2, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54660, 2660, '查询', '/find', 3, 1, null, 1, 'sys:menu:read', 1, 4, 1, '/find');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54661, 2660, '新建', '/save', 3, 2, null, 2, 'sys:menu:create', 1, 4, 1, '/save');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54662, 2660, '删除', '/delete', 3, 4, null, 3, 'sys:menu:delete', 1, 4, 1, '/delete');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54663, 2660, '保存', '/save', 3, null, null, 4, 'sys:menu:save', 1, 4, 1, '/save');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54664, 2660, '导出', '/export', 3, 6, null, 5, 'sys:menu:export', 1, 4, 1, '/export');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54667, 2672, '新建', '', 3, 2, '', 2, 'sys:role:create', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54668, 2672, '批量删除', '', 3, 4, '', 6, 'sys:role:delete', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54669, 2672, '删除', '', 3, 4, '', 5, 'sys:role:delete', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54670, 2672, '修改', '', 3, 3, '', 3, 'sys:role:update', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54673, 2672, '查询', '', 3, 1, '', 1, 'sys:role:read', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54674, 2672, '保存', '', 3, 2, '', 4, 'sys:role:save', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54699, 2668, '查询', '', 3, 1, '', 1, 'sys:user:read', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54700, 2668, '新建', '', 3, 1, '', 2, 'sys:user:create', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54701, 2668, '修改', '', 3, 1, '', 3, 'sys:user:update', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54702, 2668, '保存', '', 3, 1, '', 4, 'sys:user:save', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54703, 2668, '删除', '', 3, 1, '', 5, 'sys:user:delete', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54704, 2668, '批量删除', '', 3, 1, '', 6, 'sys:user:delete', 1, 4, 1, '');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54728, 3043, 'SQL监控', '/log/sql', 2, 1, null, 4, 'sqlLog', 1, 3, 1, '/views/system/SqlLog');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54729, 3043, '登录日志', '/log/login', 2, 1, null, 1, 'loginLog', 1, 3, 1, '/views/system/LoginLog');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54731, 2668, '密码重置', null, 3, 3, null, 7, 'sys:user:rstpw', 1, 4, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54732, 3043, '操作日志', '/log/operation', 2, 1, null, 2, 'operationLog', 1, 3, 1, '/views/system/OperationLog');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54748, 54728, '查询', null, 3, 1, null, 1, 'sys:sqllog:read', 1, 4, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54749, 54729, '查询', null, 3, 1, null, 1, 'sys:loginlog:read', 1, 4, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54750, 54732, '查询', null, 3, 1, null, 1, 'sys:operationlog:read', 1, 4, 1, null);
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54756, 3043, '异常日志', '/log/exception', 2, 1, null, 3, 'exceptionLog', 1, 3, 1, '/views/system/ExceptionLog');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54768, 3045, '地图操作', '/views/Map/MainApp', 2, 1, null, 1, 'mapOperation', 1, 3, 1, '/views/Map/MainApp');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54769, 3045, '显示设置', '/views/Map/MainApp', 2, 1, null, 2, 'displaySettings', 1, 3, 1, '/views/Map/MainApp');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54770, 3045, '地图查询', '/views/Map/MainApp', 2, 1, null, 3, 'mapQuery', 1, 3, 1, '/views/Map/MainApp');
INSERT INTO sys_menu (id, parent_id, name, route, node_prop, type, icon, index_, code, status, level, tenant_id, file_path) VALUES (54771, 3045, '统计分析', '/views/Map/MainApp', 2, 1, null, 4, 'statisticalAnalysis', 1, 3, 1, '/views/Map/MainApp');




DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) default NULL COMMENT '角色名称',
  `label` varchar(100) default NULL COMMENT '名称',
  `tenant_id` int(10) unsigned default '0' COMMENT '创建者ID',
  `remark` varchar(200) default NULL COMMENT '备注',
  `status` varchar(1) default NULL COMMENT '状态 1 有效   0 失效',
  PRIMARY KEY  USING BTREE (`id`),
  KEY `FK_company` (`tenant_id`),
  CONSTRAINT `FK_company` FOREIGN KEY (`tenant_id`) REFERENCES `sys_company` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='角色';

INSERT INTO sys_role (id, name, label, tenant_id, remark, status) VALUES (1, 'ROLE_SUPER_ADMIN', '超级管理员', 1, null, '1');
INSERT INTO sys_role (id, name, label, tenant_id, remark, status) VALUES (2, 'ROLE_ADMIN', 'ROLE_ADMIN', 1, null, '1');


DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `id` bigint(20) NOT NULL auto_increment,
  `role_id` int(10) unsigned default NULL COMMENT '角色ID',
  `menu_id` bigint(20) default NULL COMMENT '菜单ID',
  `tri_state` varchar(1) default NULL COMMENT '选中状态, 0:不选; 1:半选; 2:全选',
  PRIMARY KEY  (`id`),
  KEY `Index_role` (`role_id`,`tri_state`),
  CONSTRAINT `FK_sys_role_menu_1` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='角色与菜单对应关系';

INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (1, 1, 3040, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (2, 1, 3041, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (3, 1, 2660, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (4, 1, 54660, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (5, 1, 54661, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (6, 1, 54662, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (7, 1, 54663, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (8, 1, 54664, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (9, 1, 2672, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (10, 1, 54673, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (11, 1, 54667, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (12, 1, 54670, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (13, 1, 54674, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (14, 1, 54669, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (15, 1, 54668, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (16, 1, 2668, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (17, 1, 54699, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (18, 1, 54700, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (19, 1, 54701, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (20, 1, 54702, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (21, 1, 54703, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (22, 1, 54704, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (23, 1, 54731, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (24, 1, 3043, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (25, 1, 54729, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (26, 1, 54749, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (27, 1, 54732, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (28, 1, 54750, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (29, 1, 54756, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (30, 1, 54728, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (31, 1, 54748, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (32, 1, 54758, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (33, 1, 54768, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (34, 1, 54762, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (35, 1, 54765, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (36, 1, 54764, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (37, 1, 54759, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (38, 1, 54760, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (39, 1, 54761, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (40, 1, 54766, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (41, 1, 54767, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (42, 1, 54763, '2');

INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (43, 1, 3045, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (44, 1, 54768, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (45, 1, 54769, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (46, 1, 54770, '2');
INSERT INTO sys_role_menu (id, role_id, menu_id, tri_state) VALUES (47, 1, 54771, '2');

DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) default NULL COMMENT '密码',
  `salt` varchar(50) default NULL COMMENT '盐',
  `email` varchar(100) default NULL COMMENT '邮箱',
  `mobile` varchar(100) default NULL COMMENT '手机号',
  `status` tinyint(3) unsigned default NULL COMMENT '状态  0：禁用   1：正常',
  `create_user_id` bigint(20) unsigned default NULL COMMENT '创建者ID',
  `create_time` bigint(20) unsigned default NULL COMMENT '创建时间',
  `tenant_id` int(10) unsigned NOT NULL,
  `expired_time` bigint(20) unsigned default NULL COMMENT '失效日期',
  `name` varchar(200) NOT NULL,
  PRIMARY KEY  USING BTREE (`id`),
  KEY `FK_sys_company` (`tenant_id`),
  CONSTRAINT `FK_sys_company` FOREIGN KEY (`tenant_id`) REFERENCES `sys_company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统用户';

INSERT INTO sys_user (id, username, password, salt, email, mobile, status, create_user_id, create_time, tenant_id, expired_time, name) VALUES (1, 'admin', '01e1832d6542e33a1cbef5c30cfd6d63244bd1b488db7200286b122f88c0d3f0', 'vHyPDQBAVcGUWByt', 'root@renren.io', '13612345678', 1, 1, 2016, 1, 0, '管理员');


DROP TABLE IF EXISTS `sys_user_permission`;
CREATE TABLE `sys_user_permission` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `user_id` int(10) unsigned default NULL,
  `area_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `user_id` bigint(20) unsigned default NULL COMMENT '用户ID',
  `role_id` int(11) unsigned default NULL COMMENT '角色ID',
  PRIMARY KEY  (`id`),
  KEY `FK_sys_role` (`role_id`),
  KEY `FK_sys_user` (`user_id`),
  CONSTRAINT `FK_sys_role` FOREIGN KEY (`role_id`) REFERENCES `sys_role` (`id`),
  CONSTRAINT `FK_sys_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户与角色对应关系';

INSERT INTO sys_user_role (id, user_id, role_id) VALUES (1, 1, 1);
INSERT INTO sys_user_role (id, user_id, role_id) VALUES (2, 1, 2);


DROP TABLE IF EXISTS `sys_user_token`;
CREATE TABLE `sys_user_token` (
  `id` bigint(20) NOT NULL auto_increment,
  `token` varchar(100) NOT NULL COMMENT 'token',
  `session` text NOT NULL COMMENT 'session对象',
  `expire_time` datetime default NULL COMMENT '过期时间',
  `update_time` datetime default NULL COMMENT '更新时间',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='系统用户Token';


